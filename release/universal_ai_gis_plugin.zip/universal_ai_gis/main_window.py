"""Universal AI GIS Studio — Main plugin window (dock widget content).

Functional PyQt6 UI panels for Universal AI GIS Studio. Uses QGIS Bridge
via HTTP client to execute real GIS operations.
"""

import json
import threading
import time
from typing import Optional
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem, QLabel,
    QStackedWidget, QSplitter, QHBoxLayout, QTextEdit, QLineEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QFormLayout,
    QGroupBox, QSpinBox, QCheckBox, QHeaderView, QMessageBox,
    QToolBar, QSlider, QDoubleSpinBox, QComboBox, QProgressBar,
    QFrame, QSizePolicy
)
from qgis.PyQt.QtCore import Qt, QTimer, QShortcut, QUrl, pyqtSignal, QObject
from qgis.PyQt.QtGui import QPixmap, QImage, QKeySequence, QIcon, QFont
from qgis.PyQt.QtCore import QBuffer, QByteArray, QIODevice, QEventLoop
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply

import base64
import uuid


class BridgeClient(QObject):
    """HTTP client for communicating with the QGIS Bridge server."""

    response_received = pyqtSignal(str, dict)  # request_id, response
    error_occurred = pyqtSignal(str, str)  # request_id, error_message

    def __init__(self, base_url: str = "http://127.0.0.1:8765", auth_token: str = ""):
        super().__init__()
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self.manager = QNetworkAccessManager(self)
        self.manager.finished.connect(self._on_reply_finished)
        self._pending_requests = {}

    def set_base_url(self, url: str):
        self.base_url = url.rstrip("/")

    def set_auth_token(self, token: str):
        self.auth_token = token

    def dispatch(self, tool: str, params: dict = None, timeout: int = 300,
                 require_approval: bool = False) -> str:
        """Send a dispatch request to the bridge. Returns request_id."""
        request_id = str(uuid.uuid4())[:8]
        payload = {
            "request_id": request_id,
            "tool": tool,
            "params": params or {},
            "timeout_seconds": timeout,
            "require_approval": require_approval,
        }

        url = QUrl(f"{self.base_url}/dispatch")
        request = QNetworkRequest(url)
        request.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        if self.auth_token:
            request.setRawHeader(b"Authorization", f"Bearer {self.auth_token}".encode())

        self._pending_requests[request_id] = time.time()
        self.manager.post(request, json.dumps(payload).encode("utf-8"))
        return request_id

    def _on_reply_finished(self, reply: QNetworkReply):
        request_id = None
        try:
            data = reply.readAll().data().decode("utf-8")
            response = json.loads(data)
            request_id = response.get("request_id", "unknown")
            if reply.error() != QNetworkReply.NetworkError.NoError:
                self.error_occurred.emit(request_id, f"HTTP {reply.error()}: {reply.errorString()}")
            else:
                self.response_received.emit(request_id, response)
        except Exception as exc:
            if request_id:
                self.error_occurred.emit(request_id, str(exc))
        finally:
            if request_id and request_id in self._pending_requests:
                del self._pending_requests[request_id]
            reply.deleteLater()

    def health_check(self) -> bool:
        """Quick health check - synchronous."""
        try:
            import urllib.request
            req = urllib.request.Request(f"{self.base_url}/health", method="GET")
            if self.auth_token:
                req.add_header("Authorization", f"Bearer {self.auth_token}")
            with urllib.request.urlopen(req, timeout=2) as resp:
                return resp.status == 200
        except Exception:
            return False


class WebSocketClient(QObject):
    """WebSocket client for real-time screen streaming."""

    frame_received = pyqtSignal(dict)
    connected = pyqtSignal()
    disconnected = pyqtSignal()
    error_occurred = pyqtSignal(str)

    def __init__(self, ws_url: str = "ws://127.0.0.1:8767"):
        super().__init__()
        self.ws_url = ws_url
        self._ws = None
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def connect(self):
        """Connect to WebSocket server."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True, name="uagis-ws-client")
        self._thread.start()

    def disconnect(self):
        """Disconnect from WebSocket server."""
        self._running = False
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass

    def send_config(self, config: dict):
        """Send configuration to server."""
        if self._ws:
            try:
                import json
                self._ws.send(json.dumps({"type": "config", "config": config}))
            except Exception as exc:
                self.error_occurred.emit(str(exc))

    def _run(self):
        """Run WebSocket client in thread."""
        try:
            import websockets
            import asyncio
            asyncio.run(self._async_run())
        except ImportError:
            self.error_occurred.emit("websockets library not available")
        except Exception as exc:
            self.error_occurred.emit(str(exc))

    async def _async_run(self):
        """Async WebSocket loop."""
        try:
            import websockets
            async with websockets.connect(self.ws_url) as ws:
                self._ws = ws
                self.connected.emit()
                # Send ping to keep alive
                ping_task = asyncio.create_task(self._ping_loop(ws))
                try:
                    async for message in ws:
                        try:
                            data = json.loads(message)
                            if data.get("type") == "frame":
                                self.frame_received.emit(data.get("data", {}))
                            elif data.get("type") == "pong":
                                pass  # Keep alive
                            elif data.get("type") == "config_ack":
                                pass  # Config acknowledged
                        except json.JSONDecodeError:
                            pass
                finally:
                    ping_task.cancel()
        except Exception as exc:
            self.error_occurred.emit(str(exc))
        finally:
            self.disconnected.emit()
            self._ws = None

    async def _ping_loop(self, ws):
        """Send periodic pings."""
        try:
            while True:
                await asyncio.sleep(10)
                await ws.send(json.dumps({"type": "ping"}))
        except asyncio.CancelledError:
            pass
        except Exception:
            pass


class UniversalAIGISMainWindow(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.bridge_client = BridgeClient()
        self.ws_client = WebSocketClient()
        self._ws_connected = False
        self._periodic_capture_active = False
        self._setup_shortcuts()
        self._build_ui()
        self._connect_signals()

    def _setup_shortcuts(self):
        """Setup keyboard shortcuts."""
        # Emergency Stop: Ctrl+Shift+X
        self.emergency_shortcut = QShortcut(QKeySequence("Ctrl+Shift+X"), self)
        self.emergency_shortcut.activated.connect(self._trigger_emergency_stop)

    def _connect_signals(self):
        """Connect bridge client signals."""
        self.bridge_client.response_received.connect(self._on_bridge_response)
        self.bridge_client.error_occurred.connect(self._on_bridge_error)
        self.ws_client.frame_received.connect(self._on_ws_frame)
        self.ws_client.connected.connect(self._on_ws_connected)
        self.ws_client.disconnected.connect(self._on_ws_disconnected)
        self.ws_client.error_occurred.connect(self._on_ws_error)

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Toolbar with Emergency Stop
        self.toolbar = self._build_toolbar()
        outer.addWidget(self.toolbar)

        # Main content area
        content = QHBoxLayout()
        content.setContentsMargins(4, 4, 4, 4)
        content.setSpacing(4)

        # Left: section navigator
        self.nav = QTreeWidget()
        self.nav.setHeaderHidden(True)
        self.nav.setMaximumWidth(240)
        sections = [
            "Dashboard", "AI Chat", "Live Screen", "AI Cursor",
            "AI Connections", "API Providers", "MCP Manager", "Agent Manager",
            "Skill Manager", "GIS Clusters", "Georeferencing", "GCP Intelligence",
            "Workflow Builder", "Algorithm Discovery", "Data Manager",
            "Quality Control", "Task History", "Security", "Settings",
            "Macro & Visual Verification",
        ]
        for s in sections:
            QTreeWidgetItem(self.nav, [s])

        # Right: stacked content (functional panels per section)
        self.stack = QStackedWidget()
        self.stack.addWidget(self._panel_dashboard())
        self.stack.addWidget(self._panel_ai_chat())
        self.stack.addWidget(self._panel_live_screen())
        self.stack.addWidget(self._panel_ai_cursor())
        self.stack.addWidget(self._panel_ai_connections())
        self.stack.addWidget(self._panel_api_providers())
        self.stack.addWidget(self._panel_mcp_manager())
        self.stack.addWidget(self._panel_agent_manager())
        self.stack.addWidget(self._panel_skill_manager())
        self.stack.addWidget(self._panel_gis_clusters())
        self.stack.addWidget(self._panel_georeferencing())
        self.stack.addWidget(self._panel_gcp_intelligence())
        self.stack.addWidget(self._panel_workflow_builder())
        self.stack.addWidget(self._panel_algorithm_discovery())
        self.stack.addWidget(self._panel_data_manager())
        self.stack.addWidget(self._panel_quality_control())
        self.stack.addWidget(self._panel_task_history())
        self.stack.addWidget(self._panel_security())
        self.stack.addWidget(self._panel_settings())
        self.stack.addWidget(self._panel_macro_verification())

        self.nav.currentItemChanged.connect(self._on_nav)

        splitter = QSplitter()
        splitter.addWidget(self.nav)
        splitter.addWidget(self.stack)
        splitter.setStretchFactor(1, 1)

        content.addWidget(splitter)
        outer.addLayout(content)

        self.nav.setCurrentItem(self.nav.topLevelItem(0))

    def _build_toolbar(self) -> QToolBar:
        """Build main toolbar with emergency stop button."""
        toolbar = QToolBar()
        toolbar.setMovable(False)
        toolbar.setIconSize(toolbar.iconSize())

        # Emergency Stop Button
        self.btn_emergency_stop = QPushButton("🛑 EMERGENCY STOP")
        self.btn_emergency_stop.setToolTip("Emergency Stop (Ctrl+Shift+X) - Stops all automation immediately")
        self.btn_emergency_stop.setMinimumHeight(36)
        self.btn_emergency_stop.setStyleSheet("""
            QPushButton {
                background-color: #ff4444;
                color: white;
                font-weight: bold;
                font-size: 13px;
                border: 2px solid #cc0000;
                border-radius: 4px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background-color: #ff6666;
            }
            QPushButton:pressed {
                background-color: #cc0000;
            }
            QPushButton:disabled {
                background-color: #888888;
                color: #cccccc;
            }
        """)
        self.btn_emergency_stop.clicked.connect(self._trigger_emergency_stop)
        toolbar.addWidget(self.btn_emergency_stop)

        toolbar.addSeparator()

        # Bridge status indicator
        self.bridge_status_label = QLabel("● Bridge: Disconnected")
        self.bridge_status_label.setStyleSheet("color: #ff4444; font-weight: bold; padding: 4px;")
        toolbar.addWidget(self.bridge_status_label)

        toolbar.addSeparator()

        # Emergency stop status
        self.emergency_status_label = QLabel("")
        self.emergency_status_label.setStyleSheet("color: #ff4444; font-weight: bold; padding: 4px;")
        toolbar.addWidget(self.emergency_status_label)

        toolbar.addStretch()

        # Settings button
        btn_settings = QPushButton("⚙ Settings")
        btn_settings.clicked.connect(lambda: self.nav.setCurrentItem(self.nav.topLevelItem(17)))
        toolbar.addWidget(btn_settings)

        return toolbar

    def _on_nav(self, current, previous):
        if current is None:
            return
        idx = self.nav.indexOfTopLevelItem(current)
        self.stack.setCurrentIndex(idx)

    # ------------------------------------------------------------------ #
    # Panel builders
    # ------------------------------------------------------------------ #
    def _label_panel(self, title, note):
        w = QWidget()
        layout = QVBoxLayout(w)
        label = QLabel(f"{title}\n\n{note}")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(label)
        return w

    def _panel_dashboard(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Universal AI GIS Studio — Dashboard"))

        # Status group
        status_group = QGroupBox("System Status")
        status_layout = QFormLayout()
        self.dashboard_bridge_status = QLabel("Checking...")
        self.dashboard_emergency_status = QLabel("Normal")
        self.dashboard_jobs_status = QLabel("0 active")
        status_layout.addRow("Bridge:", self.dashboard_bridge_status)
        status_layout.addRow("Emergency Stop:", self.dashboard_emergency_status)
        status_layout.addRow("Active Jobs:", self.dashboard_jobs_status)
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)

        # Quick actions
        actions_group = QGroupBox("Quick Actions")
        actions_layout = QVBoxLayout()
        btn_refresh = QPushButton("🔄 Refresh Status")
        btn_refresh.clicked.connect(self._refresh_status)
        actions_layout.addWidget(btn_refresh)

        btn_test_bridge = QPushButton("🔗 Test Bridge Connection")
        btn_test_bridge.clicked.connect(self._test_bridge_connection)
        actions_layout.addWidget(btn_test_bridge)

        btn_emergency_test = QPushButton("🧪 Test Emergency Stop")
        btn_emergency_test.clicked.connect(self._test_emergency_stop)
        actions_layout.addWidget(btn_emergency_test)

        actions_group.setLayout(actions_layout)
        layout.addWidget(actions_group)

        layout.addStretch()
        return w

    def _panel_ai_chat(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("AI Chat — Natural Language GIS Commands"))
        self.chat_input = QTextEdit()
        self.chat_input.setPlaceholderText("Type your GIS task here...")
        self.chat_input.setMaximumHeight(100)
        layout.addWidget(self.chat_input)
        btn = QPushButton("Send to AI Agent")
        btn.clicked.connect(self._send_chat)
        layout.addWidget(btn)
        self.chat_output = QTextEdit()
        self.chat_output.setReadOnly(True)
        layout.addWidget(self.chat_output)
        return w

    def _panel_live_screen(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        # Header with connection status
        header_layout = QHBoxLayout()
        header_layout.addWidget(QLabel("Live Screen — Desktop Capture & Streaming"))

        self.screen_ws_status = QLabel("WebSocket: Disconnected")
        self.screen_ws_status.setStyleSheet("color: #ff4444;")
        header_layout.addWidget(self.screen_ws_status)
        header_layout.addStretch()
        layout.addLayout(header_layout)

        # Screen display
        self.screen_label = QLabel("No screenshot captured yet.")
        self.screen_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.screen_label.setMinimumSize(400, 300)
        self.screen_label.setStyleSheet("border: 1px solid gray; background-color: #1a1a1a; color: #888;")
        layout.addWidget(self.screen_label, 1)

        # Controls
        controls_group = QGroupBox("Capture Controls")
        controls_layout = QVBoxLayout()

        # Single capture
        single_row = QHBoxLayout()
        btn_capture = QPushButton("📸 Capture Once")
        btn_capture.clicked.connect(self._capture_screen_once)
        single_row.addWidget(btn_capture)
        single_row.addStretch()
        controls_layout.addLayout(single_row)

        # Periodic capture
        periodic_row = QHBoxLayout()
        periodic_row.addWidget(QLabel("Interval (s):"))
        self.screen_interval = QDoubleSpinBox()
        self.screen_interval.setRange(1.0, 60.0)
        self.screen_interval.setValue(5.0)
        self.screen_interval.setSingleStep(1.0)
        periodic_row.addWidget(self.screen_interval)

        periodic_row.addWidget(QLabel("Region:"))
        self.screen_region = QLineEdit()
        self.screen_region.setPlaceholderText("left,top,right,bottom (empty=full)")
        self.screen_region.setMaximumWidth(200)
        periodic_row.addWidget(self.screen_region)

        self.screen_include_cursor = QCheckBox("Include Cursor")
        periodic_row.addWidget(self.screen_include_cursor)

        periodic_row.addStretch()
        controls_layout.addLayout(periodic_row)

        # Periodic start/stop
        periodic_btn_row = QHBoxLayout()
        self.btn_start_periodic = QPushButton("▶ Start Periodic Capture")
        self.btn_start_periodic.clicked.connect(self._start_periodic_capture)
        periodic_btn_row.addWidget(self.btn_start_periodic)

        self.btn_stop_periodic = QPushButton("⏹ Stop Periodic Capture")
        self.btn_stop_periodic.clicked.connect(self._stop_periodic_capture)
        self.btn_stop_periodic.setEnabled(False)
        periodic_btn_row.addWidget(self.btn_stop_periodic)
        periodic_btn_row.addStretch()
        controls_layout.addLayout(periodic_btn_row)

        # WebSocket streaming
        ws_row = QHBoxLayout()
        self.btn_connect_ws = QPushButton("🔌 Connect WebSocket Stream")
        self.btn_connect_ws.clicked.connect(self._toggle_websocket)
        ws_row.addWidget(self.btn_connect_ws)

        self.btn_ws_config = QPushButton("📡 Send Config")
        self.btn_ws_config.clicked.connect(self._send_ws_config)
        self.btn_ws_config.setEnabled(False)
        ws_row.addWidget(self.btn_ws_config)
        ws_row.addStretch()
        controls_layout.addLayout(ws_row)

        controls_group.setLayout(controls_layout)
        layout.addWidget(controls_group)

        # Status
        self.screen_status = QLabel("Ready")
        layout.addWidget(self.screen_status)

        return w

    def _panel_ai_cursor(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("AI Cursor — Visual Overlay Control"))

        # Position controls
        pos_group = QGroupBox("Position")
        pos_layout = QFormLayout()
        self.cursor_x = QSpinBox()
        self.cursor_x.setRange(0, 9999)
        self.cursor_x.setValue(400)
        self.cursor_y = QSpinBox()
        self.cursor_y.setRange(0, 9999)
        self.cursor_y.setValue(300)
        pos_layout.addRow("X:", self.cursor_x)
        pos_layout.addRow("Y:", self.cursor_y)
        pos_group.setLayout(pos_layout)
        layout.addWidget(pos_group)

        # Movement controls
        move_group = QGroupBox("Movement")
        move_layout = QVBoxLayout()

        btn_row1 = QHBoxLayout()
        btn_move = QPushButton("🎯 Move Cursor (Smooth)")
        btn_move.clicked.connect(self._cursor_move_smooth)
        btn_row1.addWidget(btn_move)

        btn_move_instant = QPushButton("⚡ Move Cursor (Instant)")
        btn_move_instant.clicked.connect(self._cursor_move_instant)
        btn_row1.addWidget(btn_move_instant)
        move_layout.addLayout(btn_row1)

        btn_row2 = QHBoxLayout()
        btn_click = QPushButton("🖱 Click")
        btn_click.clicked.connect(self._cursor_click)
        btn_row2.addWidget(btn_click)

        btn_right_click = QPushButton("🖱 Right Click")
        btn_right_click.clicked.connect(lambda: self._cursor_click("right"))
        btn_row2.addWidget(btn_right_click)
        move_layout.addLayout(btn_row2)

        btn_drag = QPushButton("🖱 Drag")
        btn_drag.clicked.connect(self._cursor_drag)
        move_layout.addWidget(btn_drag)

        move_group.setLayout(move_layout)
        layout.addWidget(move_group)

        # Visual effects controls
        effects_group = QGroupBox("Visual Effects")
        effects_layout = QFormLayout()

        self.cursor_highlight_radius = QSpinBox()
        self.cursor_highlight_radius.setRange(5, 100)
        self.cursor_highlight_radius.setValue(20)
        self.cursor_highlight_radius.valueChanged.connect(self._on_highlight_radius_changed)
        effects_layout.addRow("Highlight Radius:", self.cursor_highlight_radius)

        self.cursor_show_highlight = QCheckBox("Show Target Highlight")
        self.cursor_show_highlight.setChecked(True)
        self.cursor_show_highlight.toggled.connect(self._on_show_highlight_changed)
        effects_layout.addRow("", self.cursor_show_highlight)

        self.cursor_show_ripple = QCheckBox("Show Click Ripple")
        self.cursor_show_ripple.setChecked(True)
        self.cursor_show_ripple.toggled.connect(self._on_show_ripple_changed)
        effects_layout.addRow("", self.cursor_show_ripple)

        self.cursor_show_trail = QCheckBox("Show Movement Trail")
        self.cursor_show_trail.setChecked(True)
        self.cursor_show_trail.toggled.connect(self._on_show_trail_changed)
        effects_layout.addRow("", self.cursor_show_trail)

        self.cursor_trail_length = QSpinBox()
        self.cursor_trail_length.setRange(5, 100)
        self.cursor_trail_length.setValue(30)
        self.cursor_trail_length.valueChanged.connect(self._on_trail_length_changed)
        effects_layout.addRow("Trail Length:", self.cursor_trail_length)

        effects_group.setLayout(effects_layout)
        layout.addWidget(effects_group)

        # Cursor state
        state_group = QGroupBox("Cursor State")
        state_layout = QFormLayout()
        self.cursor_status_pos = QLabel("(0, 0)")
        self.cursor_status_active = QLabel("Inactive")
        self.cursor_status_paused = QLabel("No")
        self.cursor_status_emergency = QLabel("Normal")
        state_layout.addRow("Position:", self.cursor_status_pos)
        state_layout.addRow("Active:", self.cursor_status_active)
        state_layout.addRow("Paused:", self.cursor_status_paused)
        state_layout.addRow("Emergency:", self.cursor_status_emergency)
        state_group.setLayout(state_layout)
        layout.addWidget(state_group)

        # Control buttons
        ctrl_group = QGroupBox("Controls")
        ctrl_layout = QVBoxLayout()
        btn_pause = QPushButton("⏸ Pause Cursor")
        btn_pause.clicked.connect(self._cursor_pause)
        ctrl_layout.addWidget(btn_pause)

        btn_resume = QPushButton("▶ Resume Cursor")
        btn_resume.clicked.connect(self._cursor_resume)
        ctrl_layout.addWidget(btn_resume)

        btn_emergency = QPushButton("🛑 Emergency Stop Cursor")
        btn_emergency.clicked.connect(self._cursor_emergency_stop)
        btn_emergency.setStyleSheet("background-color: #ff4444; color: white; font-weight: bold;")
        ctrl_layout.addWidget(btn_emergency)

        btn_release = QPushButton("✅ Release Emergency Stop")
        btn_release.clicked.connect(self._cursor_release_emergency)
        ctrl_layout.addWidget(btn_release)

        ctrl_group.setLayout(ctrl_layout)
        layout.addWidget(ctrl_group)

        layout.addStretch()
        return w

    def _panel_ai_connections(self):
        return self._label_panel("AI Connections", "Connect to OpenCode, Codex, or MCP clients.")

    def _panel_api_providers(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("API Providers — OpenAI, Gemini, Anthropic, OpenRouter"))
        form = QFormLayout()
        self.api_provider = QLineEdit()
        self.api_key = QLineEdit()
        self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
        form.addRow("Provider:", self.api_provider)
        form.addRow("API Key:", self.api_key)
        layout.addLayout(form)
        btn = QPushButton("Save Provider")
        btn.clicked.connect(self._save_api_provider)
        layout.addWidget(btn)
        return w

    def _panel_mcp_manager(self):
        return self._label_panel("MCP Manager", "Manage external MCP servers and tool trust levels.")

    def _panel_agent_manager(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Agent Manager — 29 Built-in Agents"))
        self.agent_table = QTableWidget(0, 3)
        self.agent_table.setHorizontalHeaderLabels(["Agent ID", "Name", "Action"])
        self.agent_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.agent_table)
        btn_refresh = QPushButton("Refresh Agents")
        btn_refresh.clicked.connect(self._refresh_agents)
        layout.addWidget(btn_refresh)
        return w

    def _panel_skill_manager(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Skill Manager — Import & Validate Skills"))
        btn_import = QPushButton("Import Skill")
        btn_import.clicked.connect(self._import_skill)
        layout.addWidget(btn_import)
        btn_validate = QPushButton("Validate Skills")
        btn_validate.clicked.connect(self._validate_skills)
        layout.addWidget(btn_validate)
        return w

    def _panel_gis_clusters(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("GIS Clusters — M01 to M25"))
        self.cluster_table = QTableWidget(0, 3)
        self.cluster_table.setHorizontalHeaderLabels(["Cluster ID", "Name", "Action"])
        self.cluster_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.cluster_table)
        btn_refresh = QPushButton("Refresh Clusters")
        btn_refresh.clicked.connect(self._refresh_clusters)
        layout.addWidget(btn_refresh)
        return w

    def _panel_georeferencing(self):
        return self._label_panel("Georeferencing", "Auto georeference scanned maps using CV and GCP.")

    def _panel_gcp_intelligence(self):
        return self._label_panel("GCP Intelligence", "Generate, validate, and optimize Ground Control Points.")

    def _panel_workflow_builder(self):
        return self._label_panel("Workflow Builder", "Create and execute GIS workflows visually.")

    def _panel_algorithm_discovery(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Algorithm Discovery — QGIS Processing Algorithms"))
        btn_discover = QPushButton("Discover Algorithms")
        btn_discover.clicked.connect(self._discover_algorithms)
        layout.addWidget(btn_discover)
        self.algo_output = QTextEdit()
        self.algo_output.setReadOnly(True)
        self.algo_output.setMaximumHeight(200)
        layout.addWidget(self.algo_output)
        return w

    def _panel_data_manager(self):
        return self._label_panel("Data Manager", "Load, inspect, and remove GIS data layers.")

    def _panel_quality_control(self):
        return self._label_panel("Quality Control", "Validate geometry, topology, and data quality.")

    def _panel_task_history(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Task History — Job Execution Log"))
        self.history_output = QTextEdit()
        self.history_output.setReadOnly(True)
        layout.addWidget(self.history_output)
        return w

    def _panel_security(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Security — Permissions, Approvals, and Audit Logs"))

        btn_refresh_audit = QPushButton("🔄 Refresh Audit Log")
        btn_refresh_audit.clicked.connect(self._refresh_audit_log)
        layout.addWidget(btn_refresh_audit)

        self.audit_output = QTextEdit()
        self.audit_output.setReadOnly(True)
        self.audit_output.setFont(QFont("Consolas", 9))
        layout.addWidget(self.audit_output)

        return w

    def _panel_settings(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Settings — Bridge & Connection Configuration"))
        form = QFormLayout()
        self.bridge_url = QLineEdit("http://127.0.0.1:8765")
        self.bridge_token = QLineEdit()
        self.bridge_token.setEchoMode(QLineEdit.EchoMode.Password)
        self.ws_url = QLineEdit("ws://127.0.0.1:8767")
        form.addRow("Bridge URL:", self.bridge_url)
        form.addRow("Auth Token:", self.bridge_token)
        form.addRow("WebSocket URL:", self.ws_url)
        layout.addLayout(form)
        btn = QPushButton("Save Settings")
        btn.clicked.connect(self._save_settings)
        layout.addWidget(btn)
        return w

    def _panel_macro_verification(self):
        """Macro Recorder & Visual Verification panel."""
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel("Macro Recorder & Visual Verification"))

        # --- Macro Recorder Section ---
        macro_group = QGroupBox("🎬 Macro Recorder")
        macro_layout = QVBoxLayout()

        # Macro name and description
        form = QFormLayout()
        self.macro_name = QLineEdit()
        self.macro_name.setPlaceholderText("My Macro")
        self.macro_description = QLineEdit()
        self.macro_description.setPlaceholderText("Description...")
        form.addRow("Name:", self.macro_name)
        form.addRow("Description:", self.macro_description)
        macro_layout.addLayout(form)

        # Recording controls
        rec_controls = QHBoxLayout()
        self.btn_macro_record = QPushButton("⏺ Start Recording")
        self.btn_macro_record.clicked.connect(self._macro_start_recording)
        self.btn_macro_record.setStyleSheet("background-color: #ff4444; color: white; font-weight: bold;")
        rec_controls.addWidget(self.btn_macro_record)

        self.btn_macro_stop = QPushButton("⏹ Stop Recording")
        self.btn_macro_stop.clicked.connect(self._macro_stop_recording)
        self.btn_macro_stop.setEnabled(False)
        rec_controls.addWidget(self.btn_macro_stop)

        self.btn_macro_save = QPushButton("💾 Save Macro")
        self.btn_macro_save.clicked.connect(self._macro_save)
        rec_controls.addWidget(self.btn_macro_save)

        rec_controls.addStretch()
        macro_layout.addLayout(rec_controls)

        # Playback controls
        play_controls = QHBoxLayout()
        self.macro_speed = QDoubleSpinBox()
        self.macro_speed.setRange(0.1, 10.0)
        self.macro_speed.setValue(1.0)
        self.macro_speed.setSingleStep(0.1)
        play_controls.addWidget(QLabel("Speed:"))
        play_controls.addWidget(self.macro_speed)

        self.btn_macro_play = QPushButton("▶ Play Macro")
        self.btn_macro_play.clicked.connect(self._macro_play)
        play_controls.addWidget(self.btn_macro_play)

        self.btn_macro_pause = QPushButton("⏸ Pause")
        self.btn_macro_pause.clicked.connect(self._macro_pause)
        self.btn_macro_pause.setEnabled(False)
        play_controls.addWidget(self.btn_macro_pause)

        self.btn_macro_stop_play = QPushButton("⏹ Stop")
        self.btn_macro_stop_play.clicked.connect(self._macro_stop_play)
        self.btn_macro_stop_play.setEnabled(False)
        play_controls.addWidget(self.btn_macro_stop_play)

        play_controls.addStretch()
        macro_layout.addLayout(play_controls)

        # Template variables
        template_group = QGroupBox("Template Variables (for parameterization)")
        template_layout = QVBoxLayout()
        self.template_table = QTableWidget(0, 4)
        self.template_table.setHorizontalHeaderLabels(["Variable", "Default Value", "Type", "Description"])
        self.template_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        template_layout.addWidget(self.template_table)

        template_btns = QHBoxLayout()
        btn_add_template = QPushButton("➕ Add Variable")
        btn_add_template.clicked.connect(self._macro_add_template)
        template_btns.addWidget(btn_add_template)

        btn_remove_template = QPushButton("➖ Remove Selected")
        btn_remove_template.clicked.connect(self._macro_remove_template)
        template_btns.addWidget(btn_remove_template)
        template_btns.addStretch()
        template_layout.addLayout(template_btns)
        template_group.setLayout(template_layout)
        macro_layout.addWidget(template_group)

        # Macro list
        list_group = QGroupBox("Saved Macros")
        list_layout = QVBoxLayout()
        self.macro_list = QTableWidget(0, 5)
        self.macro_list.setHorizontalHeaderLabels(["ID", "Name", "Events", "Duration (s)", "Actions"])
        self.macro_list.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        list_layout.addWidget(self.macro_list)

        list_btns = QHBoxLayout()
        btn_refresh_macros = QPushButton("🔄 Refresh List")
        btn_refresh_macros.clicked.connect(self._macro_refresh_list)
        list_btns.addWidget(btn_refresh_macros)

        btn_import_macro = QPushButton("📥 Import")
        btn_import_macro.clicked.connect(self._macro_import)
        list_btns.addWidget(btn_import_macro)

        btn_export_macro = QPushButton("📤 Export")
        btn_export_macro.clicked.connect(self._macro_export)
        list_btns.addWidget(btn_export_macro)
        list_btns.addStretch()
        list_layout.addLayout(list_btns)
        list_group.setLayout(list_layout)
        macro_layout.addWidget(list_group)

        macro_group.setLayout(macro_layout)
        layout.addWidget(macro_group)

        # --- Visual Verification Section ---
        verify_group = QGroupBox("🔍 Visual Verification")
        verify_layout = QVBoxLayout()

        # Image comparison
        compare_form = QFormLayout()
        self.verify_ref_image = QLineEdit()
        self.verify_ref_image.setPlaceholderText("Path or base64 reference image")
        self.verify_test_image = QLineEdit()
        self.verify_test_image.setPlaceholderText("Path or base64 test image")
        compare_form.addRow("Reference:", self.verify_ref_image)
        compare_form.addRow("Test:", self.verify_test_image)

        self.verify_threshold = QDoubleSpinBox()
        self.verify_threshold.setRange(0.0, 1.0)
        self.verify_threshold.setValue(0.95)
        self.verify_threshold.setSingleStep(0.01)
        compare_form.addRow("SSIM Threshold:", self.verify_threshold)

        self.verify_ignore_regions = QLineEdit()
        self.verify_ignore_regions.setPlaceholderText("x,y,w,h;x,y,w,h (regions to ignore)")
        compare_form.addRow("Ignore Regions:", self.verify_ignore_regions)

        verify_layout.addLayout(compare_form)

        # Compare button
        btn_compare = QPushButton("🔍 Compare Images")
        btn_compare.clicked.connect(self._verify_compare)
        verify_layout.addWidget(btn_compare)

        # Results
        self.verify_result = QTextEdit()
        self.verify_result.setReadOnly(True)
        self.verify_result.setMaximumHeight(200)
        self.verify_result.setFont(QFont("Consolas", 9))
        verify_layout.addWidget(self.verify_result)

        # Diff image display
        self.verify_diff_label = QLabel("Diff image will appear here")
        self.verify_diff_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.verify_diff_label.setMinimumSize(400, 200)
        self.verify_diff_label.setStyleSheet("border: 1px solid gray; background-color: #1a1a1a; color: #888;")
        verify_layout.addWidget(self.verify_diff_label)

        verify_group.setLayout(verify_layout)
        layout.addWidget(verify_group)

        # Batch comparison
        batch_group = QGroupBox("📁 Batch Comparison")
        batch_layout = QVBoxLayout()
        batch_form = QFormLayout()
        self.batch_ref_dir = QLineEdit()
        self.batch_ref_dir.setPlaceholderText("Reference directory")
        self.batch_test_dir = QLineEdit()
        self.batch_test_dir.setPlaceholderText("Test directory")
        self.batch_pattern = QLineEdit("*.png")
        batch_form.addRow("Reference Dir:", self.batch_ref_dir)
        batch_form.addRow("Test Dir:", self.batch_test_dir)
        batch_form.addRow("Pattern:", self.batch_pattern)
        batch_layout.addLayout(batch_form)

        btn_batch_compare = QPushButton("📊 Run Batch Comparison")
        btn_batch_compare.clicked.connect(self._verify_batch_compare)
        batch_layout.addWidget(btn_batch_compare)

        self.batch_result = QTextEdit()
        self.batch_result.setReadOnly(True)
        self.batch_result.setMaximumHeight(150)
        self.batch_result.setFont(QFont("Consolas", 9))
        batch_layout.addWidget(self.batch_result)

        batch_group.setLayout(batch_layout)
        layout.addWidget(batch_group)

        layout.addStretch()
        return w

    # ------------------------------------------------------------------ #
    # Bridge Communication
    # ------------------------------------------------------------------ #
    def _send_bridge_request(self, tool: str, params: dict = None,
                              callback: callable = None, error_callback: callable = None) -> str:
        """Send a request to the bridge and handle response via callbacks."""
        request_id = self.bridge_client.dispatch(tool, params)

        # Store callbacks for this request
        if not hasattr(self, '_request_callbacks'):
            self._request_callbacks = {}
        self._request_callbacks[request_id] = {
            'callback': callback,
            'error_callback': error_callback,
            'tool': tool
        }
        return request_id

    def _on_bridge_response(self, request_id: str, response: dict):
        """Handle bridge response."""
        if hasattr(self, '_request_callbacks') and request_id in self._request_callbacks:
            cb_info = self._request_callbacks.pop(request_id)
            if cb_info['callback']:
                cb_info['callback'](response)
        else:
            # Default handling based on tool
            self._handle_default_response(request_id, response)

    def _on_bridge_error(self, request_id: str, error: str):
        """Handle bridge error."""
        if hasattr(self, '_request_callbacks') and request_id in self._request_callbacks:
            cb_info = self._request_callbacks.pop(request_id)
            if cb_info['error_callback']:
                cb_info['error_callback'](error)
            else:
                QMessageBox.warning(self, f"Bridge Error ({cb_info['tool']})", error)
        else:
            QMessageBox.warning(self, "Bridge Error", error)

    def _handle_default_response(self, request_id: str, response: dict):
        """Default response handler."""
        pass

    # ------------------------------------------------------------------ #
    # Dashboard Actions
    # ------------------------------------------------------------------ #
    def _refresh_status(self):
        self.dashboard_status.setText("Checking...")
        self._send_bridge_request("qgis.system.health", {},
            callback=self._on_health_response)

    def _on_health_response(self, response: dict):
        result = response.get("result", {})
        qgis_connected = result.get("qgis_connected", False)
        layer_count = result.get("layer_count", 0)
        project_open = result.get("project_open", False)

        status_text = f"QGIS: {'Connected' if qgis_connected else 'Disconnected'} | Project: {'Open' if project_open else 'Closed'} | Layers: {layer_count}"
        self.dashboard_status.setText(status_text)

        if hasattr(self, 'dashboard_bridge_status'):
            self.dashboard_bridge_status.setText("Connected" if qgis_connected else "Disconnected")
            self.dashboard_bridge_status.setStyleSheet("color: #44ff44;" if qgis_connected else "color: #ff4444;")

        if hasattr(self, 'bridge_status_label'):
            self.bridge_status_label.setText(f"● Bridge: {'Connected' if qgis_connected else 'Disconnected'}")
            self.bridge_status_label.setStyleSheet(f"color: {'#44ff44' if qgis_connected else '#ff4444'}; font-weight: bold; padding: 4px;")

    def _test_bridge_connection(self):
        connected = self.bridge_client.health_check()
        if connected:
            QMessageBox.information(self, "Bridge Test", "✅ Bridge connection successful!")
            self._refresh_status()
        else:
            QMessageBox.warning(self, "Bridge Test", "❌ Bridge connection failed. Check if bridge server is running.")

    def _test_emergency_stop(self):
        self._send_bridge_request("qgis.system.inspect", {},
            callback=lambda r: QMessageBox.information(self, "Emergency Stop Test", "Bridge responded - emergency stop system is reachable"))

    # ------------------------------------------------------------------ #
    # Live Screen Actions
    # ------------------------------------------------------------------ #
    def _capture_screen_once(self):
        self.screen_status.setText("Capturing...")
        self._send_bridge_request("qgis.screen.capture", {},
            callback=self._on_screen_capture_response)

    def _on_screen_capture_response(self, response: dict):
        result = response.get("result", {})
        image_b64 = result.get("image_base64")
        if image_b64:
            try:
                img_data = base64.b64decode(image_b64)
                pixmap = QPixmap()
                pixmap.loadFromData(img_data, "PNG")
                scaled = pixmap.scaled(
                    self.screen_label.size(),
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
                self.screen_label.setPixmap(scaled)
                self.screen_status.setText(f"Captured: {result.get('width')}x{result.get('height')}")
            except Exception as exc:
                self.screen_status.setText(f"Display error: {exc}")
        else:
            self.screen_status.setText("Capture failed: no image data")

    def _start_periodic_capture(self):
        interval = self.screen_interval.value()
        region_text = self.screen_region.text().strip()
        region = None
        if region_text:
            try:
                parts = [int(x.strip()) for x in region_text.split(",")]
                if len(parts) == 4:
                    region = parts
            except ValueError:
                QMessageBox.warning(self, "Invalid Region", "Region must be: left,top,right,bottom")
                return

        include_cursor = self.screen_include_cursor.isChecked()

        self._send_bridge_request("qgis.screen.capture.start_periodic", {
            "interval_seconds": interval,
            "region": region,
            "include_cursor": include_cursor
        }, callback=self._on_periodic_start_response)

    def _on_periodic_start_response(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "started":
            self._periodic_capture_active = True
            self.btn_start_periodic.setEnabled(False)
            self.btn_stop_periodic.setEnabled(True)
            self.screen_status.setText(f"Periodic capture started: {result.get('interval')}s interval")
        else:
            self.screen_status.setText(f"Failed to start: {result.get('status')}")

    def _stop_periodic_capture(self):
        self._send_bridge_request("qgis.screen.capture.stop_periodic", {},
            callback=self._on_periodic_stop_response)

    def _on_periodic_stop_response(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "stopped":
            self._periodic_capture_active = False
            self.btn_start_periodic.setEnabled(True)
            self.btn_stop_periodic.setEnabled(False)
            self.screen_status.setText("Periodic capture stopped")
        else:
            self.screen_status.setText(f"Stop result: {result.get('status')}")

    def _toggle_websocket(self):
        if self._ws_connected:
            self.ws_client.disconnect()
        else:
            ws_url = self.ws_url.text().strip() if hasattr(self, 'ws_url') else "ws://127.0.0.1:8767"
            self.ws_client.ws_url = ws_url
            self.ws_client.connect()

    def _on_ws_connected(self):
        self._ws_connected = True
        self.btn_connect_ws.setText("🔌 Disconnect WebSocket Stream")
        self.btn_ws_config.setEnabled(True)
        self.screen_ws_status.setText("WebSocket: Connected")
        self.screen_ws_status.setStyleSheet("color: #44ff44;")
        self.screen_status.setText("WebSocket connected - waiting for frames...")

    def _on_ws_disconnected(self):
        self._ws_connected = False
        self.btn_connect_ws.setText("🔌 Connect WebSocket Stream")
        self.btn_ws_config.setEnabled(False)
        self.screen_ws_status.setText("WebSocket: Disconnected")
        self.screen_ws_status.setStyleSheet("color: #ff4444;")
        self.screen_status.setText("WebSocket disconnected")

    def _on_ws_error(self, error: str):
        self.screen_status.setText(f"WebSocket error: {error}")

    def _on_ws_frame(self, frame: dict):
        """Handle incoming frame from WebSocket."""
        image_b64 = frame.get("image_base64")
        if image_b64:
            try:
                img_data = base64.b64decode(image_b64)
                pixmap = QPixmap()
                pixmap.loadFromData(img_data, "PNG")
                scaled = pixmap.scaled(
                    self.screen_label.size(),
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
                self.screen_label.setPixmap(scaled)
                ts = frame.get("timestamp", 0)
                self.screen_status.setText(f"Streaming: {frame.get('width')}x{frame.get('height')} @ {time.strftime('%H:%M:%S', time.localtime(ts))}")
            except Exception as exc:
                self.screen_status.setText(f"Frame display error: {exc}")

    def _send_ws_config(self):
        if not self._ws_connected:
            return
        interval = self.screen_interval.value()
        region_text = self.screen_region.text().strip()
        region = None
        if region_text:
            try:
                parts = [int(x.strip()) for x in region_text.split(",")]
                if len(parts) == 4:
                    region = parts
            except ValueError:
                return
        config = {
            "interval": interval,
            "region": region,
            "include_cursor": self.screen_include_cursor.isChecked()
        }
        self.ws_client.send_config(config)
        self.screen_status.setText("Config sent to WebSocket server")

    # ------------------------------------------------------------------ #
    # AI Cursor Actions
    # ------------------------------------------------------------------ #
    def _cursor_move_smooth(self):
        x = self.cursor_x.value()
        y = self.cursor_y.value()
        self._send_bridge_request("qgis.cursor.move", {"x": x, "y": y},
            callback=self._on_cursor_move_response)

    def _cursor_move_instant(self):
        x = self.cursor_x.value()
        y = self.cursor_y.value()
        self._send_bridge_request("qgis.cursor.move", {"x": x, "y": y, "smooth": False},
            callback=self._on_cursor_move_response)

    def _on_cursor_move_response(self, response: dict):
        result = response.get("result", {})
        if result.get("ok"):
            self.cursor_status_pos.setText(f"({result.get('x')}, {result.get('y')})")
            self.cursor_status_active.setText("Active")
            self.cursor_status_active.setStyleSheet("color: #44ff44;")
        else:
            QMessageBox.warning(self, "Cursor Move Failed", str(result))

    def _cursor_click(self, button: str = "left"):
        self._send_bridge_request("qgis.cursor.click", {"button": button},
            callback=self._on_cursor_click_response)

    def _on_cursor_click_response(self, response: dict):
        result = response.get("result", {})
        if result.get("ok"):
            self.cursor_status_pos.setText(f"Clicked: {result.get('button', 'left')}")
        else:
            QMessageBox.warning(self, "Cursor Click Failed", str(result))

    def _cursor_drag(self):
        x1 = self.cursor_x.value()
        y1 = self.cursor_y.value()
        # For drag, we'd need end coordinates - use a dialog or secondary inputs
        # For now, just show a message
        QMessageBox.information(self, "Drag", "Drag requires start and end coordinates. Use bridge API directly for now.")

    def _cursor_pause(self):
        self._send_bridge_request("qgis.cursor.pause", {},
            callback=lambda r: self._update_cursor_status(r, paused=True))

    def _cursor_resume(self):
        self._send_bridge_request("qgis.cursor.resume", {},
            callback=lambda r: self._update_cursor_status(r, paused=False))

    def _cursor_emergency_stop(self):
        self._send_bridge_request("qgis.cursor.emergency_stop", {},
            callback=lambda r: self._update_cursor_status(r, emergency=True))

    def _cursor_release_emergency(self):
        self._send_bridge_request("qgis.cursor.release_emergency_stop", {},
            callback=lambda r: self._update_cursor_status(r, emergency=False))

    def _update_cursor_status(self, response: dict, paused: bool = None, emergency: bool = None):
        result = response.get("result", {})
        if result.get("ok"):
            if paused is not None:
                self.cursor_status_paused.setText("Yes" if paused else "No")
                self.cursor_status_paused.setStyleSheet(f"color: {'#ffaa00' if paused else '#44ff44'};")
            if emergency is not None:
                self.cursor_status_emergency.setText("ACTIVE" if emergency else "Normal")
                self.cursor_status_emergency.setStyleSheet(f"color: {'#ff4444' if emergency else '#44ff44'}; font-weight: bold;")
                # Update main toolbar emergency status too
                self._update_emergency_status_display(emergency)

    def _on_highlight_radius_changed(self, value: int):
        self._send_bridge_request("qgis.cursor.set_highlight_radius", {"radius": value})

    def _on_show_highlight_changed(self, checked: bool):
        self._send_bridge_request("qgis.cursor.set_show_highlight", {"show": checked})

    def _on_show_ripple_changed(self, checked: bool):
        self._send_bridge_request("qgis.cursor.set_show_ripple", {"show": checked})

    def _on_show_trail_changed(self, checked: bool):
        self._send_bridge_request("qgis.cursor.set_show_trail", {"show": checked})

    def _on_trail_length_changed(self, value: int):
        self._send_bridge_request("qgis.cursor.set_trail_max_length", {"length": value})

    # ------------------------------------------------------------------ #
    # Emergency Stop
    # ------------------------------------------------------------------ #
    def _trigger_emergency_stop(self):
        """Trigger global emergency stop."""
        self.btn_emergency_stop.setEnabled(False)
        self.btn_emergency_stop.setText("🛑 STOPPING...")
        self.emergency_status_label.setText("🛑 EMERGENCY STOP TRIGGERED")
        self.emergency_status_label.setStyleSheet("color: #ff4444; font-weight: bold; padding: 4px; background-color: #ffebeb;")
        self.dashboard_emergency_status.setText("ACTIVE")
        self.dashboard_emergency_status.setStyleSheet("color: #ff4444; font-weight: bold;")

        # Call emergency stop on bridge
        self._send_bridge_request("qgis.system.emergency_stop", {"reason": "User triggered via UI/hotkey"},
            callback=self._on_emergency_stop_response,
            error_callback=self._on_emergency_stop_error)

    def _on_emergency_stop_response(self, response: dict):
        result = response.get("result", {})
        callbacks = result.get("callbacks_executed", 0)
        failed = result.get("callbacks_failed", 0)
        QMessageBox.critical(self, "Emergency Stop Executed",
            f"Emergency stop triggered successfully.\n"
            f"Callbacks executed: {callbacks}\n"
            f"Callbacks failed: {failed}\n\n"
            f"All automation has been stopped.")
        self.btn_emergency_stop.setEnabled(True)
        self.btn_emergency_stop.setText("🛑 EMERGENCY STOP")

    def _on_emergency_stop_error(self, error: str):
        QMessageBox.critical(self, "Emergency Stop Failed", f"Failed to trigger emergency stop:\n{error}")
        self.btn_emergency_stop.setEnabled(True)
        self.btn_emergency_stop.setText("🛑 EMERGENCY STOP")

    def _update_emergency_status_display(self, active: bool):
        """Update emergency status display across UI."""
        if active:
            self.emergency_status_label.setText("🛑 EMERGENCY STOP ACTIVE")
            self.emergency_status_label.setStyleSheet("color: #ff4444; font-weight: bold; padding: 4px; background-color: #ffebeb;")
            if hasattr(self, 'dashboard_emergency_status'):
                self.dashboard_emergency_status.setText("ACTIVE")
                self.dashboard_emergency_status.setStyleSheet("color: #ff4444; font-weight: bold;")
            if hasattr(self, 'cursor_status_emergency'):
                self.cursor_status_emergency.setText("ACTIVE")
                self.cursor_status_emergency.setStyleSheet("color: #ff4444; font-weight: bold;")
        else:
            self.emergency_status_label.setText("")
            if hasattr(self, 'dashboard_emergency_status'):
                self.dashboard_emergency_status.setText("Normal")
                self.dashboard_emergency_status.setStyleSheet("color: #44ff44;")
            if hasattr(self, 'cursor_status_emergency'):
                self.cursor_status_emergency.setText("Normal")
                self.cursor_status_emergency.setStyleSheet("color: #44ff44;")

    # ------------------------------------------------------------------ #
    # Other Panel Actions
    # ------------------------------------------------------------------ #
    def _send_chat(self):
        text = self.chat_input.toPlainText().strip()
        if not text:
            return
        self.chat_output.append(f"> {text}")
        self.chat_output.append("[AI response will appear here once MCP client is configured.]")
        self.chat_input.clear()

    def _save_api_provider(self):
        provider = self.api_provider.text().strip()
        key = self.api_key.text().strip()
        if provider and key:
            QMessageBox.information(self, "API Provider", f"Provider '{provider}' saved.")
        else:
            QMessageBox.warning(self, "API Provider", "Please enter provider and key.")

    def _refresh_agents(self):
        from agents.builtins import (
            DataAcquisitionAgent, DataManagementAgent, VectorProcessingAgent,
            RasterProcessingAgent, CRSTransformAgent, SpatialAnalysisAgent,
            TerrainAnalysisAgent, HydrologyAnalysisAgent, NetworkAnalysisAgent,
            RemoteSensingAgent, ClassificationAgent, ChangeDetectionAgent,
            Analysis3DAgent, LiDARProcessingAgent, AIMLAgent, SurveyAgent,
            CadastralAgent, CartographyAgent, TemporalAgent, DatabaseAgent,
            WebGISAgent, FieldDataAgent, AutomationAgent, QualityControlAgent,
            GeoreferencingAgent, AgentsManagerAgent, OrchestratorAgent,
            CustomBuilderAgent, SupervisorAgent,
        )
        agents = [
            DataAcquisitionAgent, DataManagementAgent, VectorProcessingAgent,
            RasterProcessingAgent, CRSTransformAgent, SpatialAnalysisAgent,
            TerrainAnalysisAgent, HydrologyAnalysisAgent, NetworkAnalysisAgent,
            RemoteSensingAgent, ClassificationAgent, ChangeDetectionAgent,
            Analysis3DAgent, LiDARProcessingAgent, AIMLAgent, SurveyAgent,
            CadastralAgent, CartographyAgent, TemporalAgent, DatabaseAgent,
            WebGISAgent, FieldDataAgent, AutomationAgent, QualityControlAgent,
            GeoreferencingAgent, AgentsManagerAgent, OrchestratorAgent,
            CustomBuilderAgent, SupervisorAgent,
        ]
        self.agent_table.setRowCount(len(agents))
        for i, agent_cls in enumerate(agents):
            agent = agent_cls()
            self.agent_table.setItem(i, 0, QTableWidgetItem(agent.agent_id))
            self.agent_table.setItem(i, 1, QTableWidgetItem(agent.name))
            btn = QPushButton("Execute")
            btn.clicked.connect(lambda _, a=agent: self._execute_agent(a))
            self.agent_table.setCellWidget(i, 2, btn)

    def _execute_agent(self, agent):
        result = agent.execute({})
        QMessageBox.information(
            self, "Agent Executed",
            f"{agent.name}\nStatus: {result.get('status', 'unknown')}\nNote: {result.get('note', '')}"
        )

    def _import_skill(self):
        QMessageBox.information(self, "Skill Manager", "Skill import dialog not yet implemented.")

    def _validate_skills(self):
        QMessageBox.information(self, "Skill Manager", "No skills found to validate.")

    def _refresh_clusters(self):
        clusters = [(f"M{i:02d}", f"Cluster {i}") for i in range(1, 26)]
        self.cluster_table.setRowCount(len(clusters))
        for i, (cid, name) in enumerate(clusters):
            self.cluster_table.setItem(i, 0, QTableWidgetItem(cid))
            self.cluster_table.setItem(i, 1, QTableWidgetItem(name))
            btn = QPushButton("Run")
            btn.clicked.connect(lambda _, c=cid: self._run_cluster(c))
            self.cluster_table.setCellWidget(i, 2, btn)

    def _run_cluster(self, cluster_id):
        QMessageBox.information(self, "Cluster", f"Cluster {cluster_id} execution not yet wired to bridge.")

    def _discover_algorithms(self):
        try:
            import processing
            from qgis.core import QgsApplication
            registry = QgsApplication.processingRegistry()
            algs = []
            for alg in registry.algorithms():
                algs.append(f"{alg.id()} — {alg.name()} [{alg.group()}]")
            self.algo_output.setPlainText("\n".join(algs[:100]))
            if len(algs) > 100:
                self.algo_output.append(f"\n... and {len(algs) - 100} more algorithms")
        except Exception as exc:
            QMessageBox.warning(self, "Algorithm Discovery", str(exc))

    def _refresh_audit_log(self):
        try:
            from database.db import Database
            from database.repositories.audit_repository import AuditRepository
            db = Database()
            db.connect()
            audit = AuditRepository(db)
            logs = audit.list(limit=50)
            db.close()

            lines = []
            for log in logs:
                ts = log.get("timestamp", "")
                actor = log.get("actor", "")
                action = log.get("action", "")
                target = log.get("target", "")
                outcome = log.get("outcome", "")
                details = log.get("details", {})
                lines.append(f"[{ts}] {actor} | {action} | {target} | {outcome}")
                if details:
                    lines.append(f"  Details: {json.dumps(details, indent=2)}")

            self.audit_output.setPlainText("\n".join(lines) if lines else "No audit logs found.")
        except Exception as exc:
            QMessageBox.warning(self, "Audit Log", f"Failed to load audit log: {exc}")

    def _save_settings(self):
        url = self.bridge_url.text().strip()
        token = self.bridge_token.text().strip()
        ws_url = self.ws_url.text().strip() if hasattr(self, 'ws_url') else "ws://127.0.0.1:8767"

        self.bridge_client.set_base_url(url)
        self.bridge_client.set_auth_token(token)
        self.ws_client.ws_url = ws_url

        QMessageBox.information(self, "Settings", f"Bridge URL: {url}\nWebSocket URL: {ws_url}\nSettings saved. Use 'Test Bridge Connection' to verify.")

    # ------------------------------------------------------------------ #
    # Macro Recorder Actions
    # ------------------------------------------------------------------ #
    def _macro_start_recording(self):
        """Start recording a macro."""
        name = self.macro_name.text().strip() or "Untitled Macro"
        description = self.macro_description.text().strip()

        # Collect template variables
        templates = []
        for row in range(self.template_table.rowCount()):
            var_item = self.template_table.item(row, 0)
            default_item = self.template_table.item(row, 1)
            type_item = self.template_table.item(row, 2)
            desc_item = self.template_table.item(row, 3)
            if var_item and var_item.text().strip():
                templates.append({
                    "name": var_item.text().strip(),
                    "default": default_item.text() if default_item else "",
                    "type": type_item.text() if type_item else "string",
                    "description": desc_item.text() if desc_item else "",
                })

        self._send_bridge_request("qgis.macro.start_recording", {
            "name": name,
            "description": description,
            "templates": templates,
        }, callback=self._on_macro_recording_started)

        self.btn_macro_record.setEnabled(False)
        self.btn_macro_stop.setEnabled(True)
        self.btn_macro_save.setEnabled(False)

    def _on_macro_recording_started(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "started":
            self.macro_status = QLabel(f"Recording: {result.get('macro_id')}")
            # Add status label if not exists
            if not hasattr(self, '_macro_status_label'):
                self._macro_status_label = QLabel("Recording...")
                self._macro_status_label.setStyleSheet("color: #ff4444; font-weight: bold;")
            self._macro_status_label.setText(f"🔴 Recording: {result.get('macro_id')}")
            self._macro_status_label.setStyleSheet("color: #ff4444; font-weight: bold;")
        else:
            QMessageBox.warning(self, "Recording Failed", str(result.get("error", "Unknown error")))
            self.btn_macro_record.setEnabled(True)
            self.btn_macro_stop.setEnabled(False)

    def _macro_stop_recording(self):
        """Stop recording a macro."""
        self._send_bridge_request("qgis.macro.stop_recording", {},
            callback=self._on_macro_recording_stopped)

    def _on_macro_recording_stopped(self, response: dict):
        result = response.get("result", {})
        if result.get("macro"):
            macro = result["macro"]
            self._macro_status_label.setText(f"✅ Recorded: {macro.get('name')} ({len(macro.get('events', []))} events)")
            self._macro_status_label.setStyleSheet("color: #44ff44; font-weight: bold;")
            self.btn_macro_record.setEnabled(True)
            self.btn_macro_stop.setEnabled(False)
            self.btn_macro_save.setEnabled(True)
            # Store the macro for saving
            self._last_recorded_macro = macro
        else:
            QMessageBox.warning(self, "Stop Failed", str(result.get("error", "Unknown error")))
            self.btn_macro_record.setEnabled(True)
            self.btn_macro_stop.setEnabled(False)

    def _macro_save(self):
        """Save the last recorded macro."""
        if not hasattr(self, '_last_recorded_macro'):
            QMessageBox.warning(self, "No Macro", "No recorded macro to save.")
            return
        self._send_bridge_request("qgis.macro.save", {"macro": self._last_recorded_macro},
            callback=self._on_macro_saved)

    def _on_macro_saved(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "saved":
            QMessageBox.information(self, "Saved", f"Macro saved: {result.get('macro_id')}")
            self._macro_refresh_list()
        else:
            QMessageBox.warning(self, "Save Failed", str(result.get("error", "Unknown error")))

    def _macro_play(self):
        """Play a macro."""
        # Get selected macro from list
        current_row = self.macro_list.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, "No Macro Selected", "Please select a macro from the list.")
            return

        macro_id = self.macro_list.item(current_row, 0).text()
        speed = self.macro_speed.value()

        self._send_bridge_request("qgis.macro.play", {
            "macro_id": macro_id,
            "speed": speed,
        }, callback=self._on_macro_play_started)

        self.btn_macro_play.setEnabled(False)
        self.btn_macro_pause.setEnabled(True)
        self.btn_macro_stop_play.setEnabled(True)

    def _on_macro_play_started(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "started":
            self._macro_status_label.setText(f"▶ Playing: {result.get('macro_id')}")
            self._macro_status_label.setStyleSheet("color: #44aaff; font-weight: bold;")
        else:
            QMessageBox.warning(self, "Play Failed", str(result.get("error", "Unknown error")))
            self.btn_macro_play.setEnabled(True)
            self.btn_macro_pause.setEnabled(False)
            self.btn_macro_stop_play.setEnabled(False)

    def _macro_pause(self):
        """Pause macro playback."""
        self._send_bridge_request("qgis.macro.pause", {},
            callback=lambda r: self._macro_status_label.setText("⏸ Paused"))

    def _macro_stop_play(self):
        """Stop macro playback."""
        self._send_bridge_request("qgis.macro.stop", {},
            callback=lambda r: self._on_macro_playback_stopped())

    def _on_macro_playback_stopped(self):
        self.btn_macro_play.setEnabled(True)
        self.btn_macro_pause.setEnabled(False)
        self.btn_macro_stop_play.setEnabled(False)
        self._macro_status_label.setText("⏹ Stopped")
        self._macro_status_label.setStyleSheet("color: #888;")

    def _macro_add_template(self):
        """Add a template variable row."""
        row = self.template_table.rowCount()
        self.template_table.insertRow(row)
        self.template_table.setItem(row, 0, QTableWidgetItem(""))
        self.template_table.setItem(row, 1, QTableWidgetItem(""))
        self.template_table.setItem(row, 2, QTableWidgetItem("string"))
        self.template_table.setItem(row, 3, QTableWidgetItem(""))

    def _macro_remove_template(self):
        """Remove selected template variable row."""
        current_row = self.template_table.currentRow()
        if current_row >= 0:
            self.template_table.removeRow(current_row)

    def _macro_refresh_list(self):
        """Refresh the macro list from storage."""
        self._send_bridge_request("qgis.macro.list", {},
            callback=self._on_macro_list_response)

    def _on_macro_list_response(self, response: dict):
        result = response.get("result", {})
        macros = result.get("macros", [])
        self.macro_list.setRowCount(len(macros))
        for i, macro in enumerate(macros):
            self.macro_list.setItem(i, 0, QTableWidgetItem(macro.get("id", "")))
            self.macro_list.setItem(i, 1, QTableWidgetItem(macro.get("name", "")))
            self.macro_list.setItem(i, 2, QTableWidgetItem(str(len(macro.get("events", [])))))
            self.macro_list.setItem(i, 3, QTableWidgetItem(f"{macro.get('duration', 0):.1f}"))

            # Action buttons
            btn_widget = QWidget()
            btn_layout = QHBoxLayout(btn_widget)
            btn_layout.setContentsMargins(2, 2, 2, 2)

            btn_play = QPushButton("▶")
            btn_play.setToolTip("Play")
            btn_play.setMaximumWidth(30)
            btn_play.clicked.connect(lambda _, m=macro: self._macro_play_selected(m))
            btn_layout.addWidget(btn_play)

            btn_export = QPushButton("📤")
            btn_export.setToolTip("Export")
            btn_export.setMaximumWidth(30)
            btn_export.clicked.connect(lambda _, m=macro: self._macro_export_selected(m))
            btn_layout.addWidget(btn_export)

            btn_delete = QPushButton("🗑")
            btn_delete.setToolTip("Delete")
            btn_delete.setMaximumWidth(30)
            btn_delete.clicked.connect(lambda _, m=macro: self._macro_delete_selected(m))
            btn_layout.addWidget(btn_delete)

            self.macro_list.setCellWidget(i, 4, btn_widget)

    def _macro_play_selected(self, macro: dict):
        """Play a specific macro from the list."""
        macro_id = macro.get("id")
        speed = self.macro_speed.value()
        self._send_bridge_request("qgis.macro.play", {
            "macro_id": macro_id,
            "speed": speed,
        }, callback=self._on_macro_play_started)

    def _macro_export_selected(self, macro: dict):
        """Export a specific macro."""
        macro_id = macro.get("id")
        self._send_bridge_request("qgis.macro.export", {"macro_id": macro_id},
            callback=self._on_macro_exported)

    def _on_macro_exported(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "exported":
            QMessageBox.information(self, "Exported", f"Macro exported to: {result.get('path')}")
        else:
            QMessageBox.warning(self, "Export Failed", str(result.get("error", "Unknown error")))

    def _macro_delete_selected(self, macro: dict):
        """Delete a specific macro."""
        macro_id = macro.get("id")
        reply = QMessageBox.question(self, "Delete Macro",
            f"Delete macro '{macro.get('name')}' ({macro_id})?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self._send_bridge_request("qgis.macro.delete", {"macro_id": macro_id},
                callback=lambda r: self._macro_refresh_list())

    def _macro_import(self):
        """Import a macro from file."""
        from qgis.PyQt.QtWidgets import QFileDialog
        file_path, _ = QFileDialog.getOpenFileName(self, "Import Macro", "", "JSON Files (*.json)")
        if file_path:
            self._send_bridge_request("qgis.macro.import", {"file_path": file_path},
                callback=self._on_macro_imported)

    def _on_macro_imported(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "imported":
            QMessageBox.information(self, "Imported", f"Macro imported: {result.get('macro_id')}")
            self._macro_refresh_list()
        else:
            QMessageBox.warning(self, "Import Failed", str(result.get("error", "Unknown error")))

    def _macro_export(self):
        """Export selected macro."""
        current_row = self.macro_list.currentRow()
        if current_row < 0:
            QMessageBox.warning(self, "No Macro Selected", "Please select a macro from the list.")
            return
        macro_id = self.macro_list.item(current_row, 0).text()
        self._macro_export_selected({"id": macro_id})

    # ------------------------------------------------------------------ #
    # Visual Verification Actions
    # ------------------------------------------------------------------ #
    def _verify_compare(self):
        """Compare two images."""
        ref_path = self.verify_ref_image.text().strip()
        test_path = self.verify_test_image.text().strip()
        threshold = self.verify_threshold.value()

        ignore_regions = []
        ignore_text = self.verify_ignore_regions.text().strip()
        if ignore_text:
            try:
                for region_str in ignore_text.split(";"):
                    parts = [int(x.strip()) for x in region_str.split(",")]
                    if len(parts) == 4:
                        ignore_regions.append(parts)
            except ValueError:
                QMessageBox.warning(self, "Invalid Regions", "Format: x,y,w,h;x,y,w,h")
                return

        self.verify_result.setText("Comparing...")
        self._send_bridge_request("qgis.visual.compare", {
            "reference": ref_path,
            "test": test_path,
            "threshold": threshold,
            "ignore_regions": ignore_regions,
        }, callback=self._on_verify_compare_response)

    def _on_verify_compare_response(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "completed":
            comparison = result.get("comparison", {})
            self.verify_result.setText(json.dumps(comparison, indent=2))

            # Display diff image if available
            diff_b64 = comparison.get("diff_image_base64")
            if diff_b64:
                try:
                    img_data = base64.b64decode(diff_b64)
                    pixmap = QPixmap()
                    pixmap.loadFromData(img_data, "PNG")
                    scaled = pixmap.scaled(
                        self.verify_diff_label.size(),
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation,
                    )
                    self.verify_diff_label.setPixmap(scaled)
                except Exception as exc:
                    self.verify_result.append(f"\nDiff display error: {exc}")
        else:
            self.verify_result.setText(f"Error: {result.get('error', 'Unknown error')}")

    def _verify_batch_compare(self):
        """Run batch comparison."""
        ref_dir = self.batch_ref_dir.text().strip()
        test_dir = self.batch_test_dir.text().strip()
        pattern = self.batch_pattern.text().strip() or "*.png"
        threshold = self.verify_threshold.value()

        if not ref_dir or not test_dir:
            QMessageBox.warning(self, "Missing Directories", "Please specify both reference and test directories.")
            return

        self.batch_result.setText("Running batch comparison...")
        self._send_bridge_request("qgis.visual.batch_compare", {
            "reference_dir": ref_dir,
            "test_dir": test_dir,
            "pattern": pattern,
            "threshold": threshold,
        }, callback=self._on_verify_batch_compare_response)

    def _on_verify_batch_compare_response(self, response: dict):
        result = response.get("result", {})
        if result.get("status") == "completed":
            results = result.get("results", [])
            lines = [f"Batch comparison completed: {len(results)} files"]
            for r in results:
                file = r.get("file", "")
                if "error" in r:
                    lines.append(f"  {file}: ERROR - {r['error']}")
                else:
                    comp = r.get("result", {})
                    status = comp.get("result", "unknown")
                    ssim = comp.get("ssim_score", 0)
                    lines.append(f"  {file}: {status} (SSIM: {ssim:.4f})")
            self.batch_result.setText("\n".join(lines))
        else:
            self.batch_result.setText(f"Error: {result.get('error', 'Unknown error')}")

    def closeEvent(self, event):
        """Clean up on close."""
        if self._ws_connected:
            self.ws_client.disconnect()
        super().closeEvent(event)