"""Universal AI GIS Studio - QGIS Plugin package."""

import sys
# Add project root to sys.path before importing plugin module
_PROJECT_ROOT = r"D:\1 2 3 QGIS\Universal-AI-GIS-Studio"
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

__version__ = "1.0.0"

from .plugin import UniversalAIGISPlugin  # noqa: E402


def classFactory(iface):  # QGIS plugin entry point
    """Instantiate the Universal AI GIS Studio plugin."""
    return UniversalAIGISPlugin(iface)
