"""Universal AI GIS Studio — Bridge HTTP request handler.

Handles authenticated POST /dispatch requests from the MCP server.
Returns JSON protocol Responses.
"""

import json
from http.server import BaseHTTPRequestHandler

from bridge.protocol import Request, error_response
from core.logging import get_logger
from core.exceptions import ConfigurationError

logger = get_logger("bridge.request_handler")


class BridgeRequestHandler(BaseHTTPRequestHandler):
    """HTTP handler for bridge dispatch. dispatcher is injected via class attr."""

    dispatcher = None
    auth_token = None

    def log_message(self, format, *args):  # noqa: A002
        logger.info("%s - %s", self.address_string(), format % args)

    def _send_json(self, status_code, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _check_auth(self) -> bool:
        if self.auth_token is None:
            return True  # auth not configured (dev)
        auth = self.headers.get("Authorization", "")
        if auth == f"Bearer {self.auth_token}":
            return True
        return False

    def do_POST(self):  # noqa: N802
        if self.path not in ("/dispatch", "/health"):
            self._send_json(404, error_response("unknown", "NOT_FOUND",
                                                "Endpoint not found").to_dict())
            return

        if self.path == "/health":
            self._send_json(200, {"status": "ok"})
            return

        if not self._check_auth():
            self._send_json(401, error_response("unknown", "UNAUTHORIZED",
                                                "Invalid or missing auth token").to_dict())
            return

        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            data = json.loads(raw.decode("utf-8")) if raw else {}
        except (json.JSONDecodeError, ValueError) as exc:
            self._send_json(400, error_response("unknown", "VALIDATION_ERROR",
                                                f"Invalid JSON body: {exc}").to_dict())
            return

        request_id = data.get("request_id")
        tool = data.get("tool")
        if not request_id or not tool:
            self._send_json(400, error_response(request_id or "unknown", "VALIDATION_ERROR",
                                                "request_id and tool are required").to_dict())
            return

        req = Request(
            request_id=request_id,
            tool=tool,
            params=data.get("params", {}),
            timeout_seconds=data.get("timeout_seconds", 300),
            require_approval=data.get("require_approval", False),
            metadata=data.get("metadata", {}),
        )

        response = self.dispatcher.dispatch(req)
        self._send_json(200, response.to_dict())

    def do_GET(self):  # noqa: N802
        if self.path == "/health":
            self._send_json(200, {"status": "ok"})
        else:
            self._send_json(404, {"error": "not_found"})
