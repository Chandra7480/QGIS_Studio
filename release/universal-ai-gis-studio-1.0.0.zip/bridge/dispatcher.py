"""Universal AI GIS Studio — Bridge Request Dispatcher.

Routes incoming bridge requests to the appropriate PyQGISExecutor method
and returns protocol Responses. Keeps routing logic separate from HTTP.
"""

from bridge.protocol import (
    Request, Response, success_response, error_response,
    VERIFICATION_SUCCESS, VERIFICATION_FAILED, VERIFICATION_NEEDS_REVIEW,
)
from bridge.executor import PyQGISExecutor
from core.logging import get_logger
from core.exceptions import NotFoundError, ExecutionError

logger = get_logger("bridge.dispatcher")


class BridgeDispatcher:
    def __init__(self, executor: PyQGISExecutor):
        self.executor = executor
        self._handlers = {
            "qgis.system.inspect": self._system_inspect,
            "qgis.system.health": self._system_health,
            "qgis.project.inspect": self._project_inspect,
            "qgis.layers.inspect": self._layers_inspect,
            "qgis.layers.load": self._layers_load,
            "qgis.layers.remove": self._layers_remove,
            "qgis.canvas.inspect": self._canvas_inspect,
            "qgis.screen.capture": self._screen_capture,
            "qgis.algorithms.discover": self._algorithms_discover,
            "qgis.algorithms.execute": self._algorithms_execute,
        }

    def dispatch(self, request: Request) -> Response:
        handler = self._handlers.get(request.tool)
        if handler is None:
            return error_response(
                request.request_id, "TOOL_NOT_FOUND",
                f"Tool {request.tool} is not registered in the bridge",
            )
        try:
            result = handler(request.params)
            return success_response(
                request.request_id, result,
                verification_state=VERIFICATION_SUCCESS,
            )
        except NotFoundError as exc:
            return error_response(request.request_id, "NOT_FOUND", str(exc))
        except ExecutionError as exc:
            return error_response(request.request_id, "EXECUTION_ERROR", str(exc),
                                  verification_state=VERIFICATION_FAILED)
        except Exception as exc:
            logger.exception("Dispatcher error for %s", request.tool)
            return error_response(request.request_id, "INTERNAL_ERROR", str(exc),
                                  verification_state=VERIFICATION_FAILED)

    # ----- individual tool handlers -----
    def _system_inspect(self, params):
        import qgis
        return {
            "qgis_version": getattr(qgis, "__version__", "unknown"),
            "bridge_version": "1.0.0",
            "main_thread": self.executor._is_main_thread(),
        }

    def _system_health(self, params):
        return self.executor.health()

    def _project_inspect(self, params):
        return self.executor.inspect_project()

    def _layers_inspect(self, params):
        return self.executor.inspect_layers()

    def _layers_load(self, params):
        path = params.get("path")
        if not path:
            raise ExecutionError("Missing required parameter: path")
        return self.executor.load_layer(
            path=path,
            layer_name=params.get("layer_name"),
            provider=params.get("provider"),
        )

    def _layers_remove(self, params):
        layer_id = params.get("layer_id")
        if not layer_id:
            raise ExecutionError("Missing required parameter: layer_id")
        return self.executor.remove_layer(layer_id)

    def _canvas_inspect(self, params):
        return self.executor.inspect_canvas()

    def _screen_capture(self, params):
        return self.executor.capture_canvas()

    def _algorithms_discover(self, params):
        import processing
        from qgis.core import QgsApplication
        registry = QgsApplication.processingRegistry()
        algs = []
        for alg in registry.algorithms():
            algs.append({
                "id": alg.id(),
                "name": alg.name(),
                "group": alg.group(),
            })
        return {"algorithms": algs, "count": len(algs)}

    def _algorithms_execute(self, params):
        algorithm_id = params.get("algorithm")
        parameters = params.get("parameters", {})
        if not algorithm_id:
            raise ExecutionError("Missing required parameter: algorithm")
        return self.executor.execute_algorithm(algorithm_id, parameters)
