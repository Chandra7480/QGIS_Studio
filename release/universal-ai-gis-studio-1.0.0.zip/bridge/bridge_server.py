"""Universal AI GIS Studio — Bridge HTTP server.

Runs inside QGIS on localhost. Serves the BridgeRequestHandler which
dispatches to the PyQGISExecutor. Threaded so QGIS GUI stays responsive.
"""

import threading
from http.server import ThreadingHTTPServer

from bridge.request_handler import BridgeRequestHandler
from core.logging import get_logger
from core.exceptions import BridgeError

logger = get_logger("bridge.server")


class BridgeServer:
    def __init__(self, host: str = "127.0.0.1", port: int = 8765,
                 auth_token: str | None = None):
        self.host = host
        self.port = port
        self.auth_token = auth_token
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._running = False

    def start(self, dispatcher) -> None:
        if self._running:
            logger.warning("Bridge server already running")
            return
        BridgeRequestHandler.dispatcher = dispatcher
        BridgeRequestHandler.auth_token = self.auth_token
        try:
            self._server = ThreadingHTTPServer((self.host, self.port),
                                               BridgeRequestHandler)
        except OSError as exc:
            raise BridgeError(f"Cannot bind bridge to {self.host}:{self.port}: {exc}") from exc
        self._thread = threading.Thread(target=self._server.serve_forever,
                                        daemon=True, name="uagis-bridge")
        self._thread.start()
        self._running = True
        logger.info("Bridge server listening on http://%s:%s", self.host, self.port)

    def stop(self) -> None:
        if not self._running or self._server is None:
            return
        self._server.shutdown()
        self._server.server_close()
        self._running = False
        logger.info("Bridge server stopped")

    @property
    def running(self) -> bool:
        return self._running
