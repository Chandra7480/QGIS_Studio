"""Universal AI GIS Studio — Bridge PyQGIS Executor.

Executes PyQGIS operations safely:
- QGIS GUI operations are marshalled to the QGIS main thread.
- Long-running work runs in QgsTask (background) but never touches GUI.
- Returns structured results with verification_state.

This module is imported only inside QGIS (PyQGIS available).
"""

import traceback
from typing import Callable, Any, Optional

from bridge.protocol import (
    VERIFICATION_SUCCESS, VERIFICATION_FAILED, VERIFICATION_PARTIAL,
    VERIFICATION_NEEDS_REVIEW,
)
from core.logging import get_logger
from core.exceptions import ExecutionError, BridgeError, UAGISTimeoutError

logger = get_logger("bridge.executor")


class PyQGISExecutor:
    """Main-thread-safe PyQGIS operation executor."""

    def __init__(self, qgis_iface):
        self.iface = qgis_iface
        self._main_thread_call = self._qt_invoke_method

    # ------------------------------------------------------------------ #
    # Main-thread marshalling
    # ------------------------------------------------------------------ #
    def _qt_invoke_method(self, fn: Callable, *args, **kwargs) -> Any:
        """Run fn on the QGIS GUI thread and return its result.

        Uses QMetaObject.invokeMethod with a blocking queued connection
        so the caller waits until the GUI thread has executed fn.
        """
        from qgis.PyQt.QtCore import QMetaObject, QThread, Qt, QObject

        result_holder = {"value": None, "error": None, "done": False}

        class _Runner(QObject):
            def run(self):
                try:
                    result_holder["value"] = fn(*args, **kwargs)
                except Exception as exc:
                    result_holder["error"] = exc
                finally:
                    result_holder["done"] = True

        runner = _Runner()
        # Move to the GUI thread (iface runs on GUI thread)
        runner.moveToThread(self.iface.mainWindow().thread())
        # Blocking queued invocation
        QMetaObject.invokeMethod(
            runner, "run",
            Qt.ConnectionType.BlockingQueuedConnection,
        )
        if result_holder["error"]:
            raise result_holder["error"]
        return result_holder["value"]

    def run_on_main_thread(self, fn: Callable, *args, **kwargs) -> Any:
        """Public wrapper to run a callable on the QGIS main thread."""
        if self._is_main_thread():
            return fn(*args, **kwargs)
        return self._main_thread_call(fn, *args, **kwargs)

    def _is_main_thread(self) -> bool:
        from qgis.PyQt.QtCore import QThread
        return QThread.currentThread() == self.iface.mainWindow().thread()

    # ------------------------------------------------------------------ #
    # Project inspection
    # ------------------------------------------------------------------ #
    def inspect_project(self) -> dict:
        def _do():
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            crs = proj.crs()
            return {
                "project_file": proj.fileName(),
                "project_title": proj.title(),
                "crs": crs.authid() if crs.isValid() else None,
                "crs_wkt": crs.toWkt() if crs.isValid() else None,
                "layer_count": len(proj.mapLayers()),
                "layers": [
                    {
                        "id": lid,
                        "name": layer.name(),
                        "type": self._layer_type(layer),
                        "valid": layer.isValid(),
                        "crs": layer.crs().authid() if layer.crs().isValid() else None,
                    }
                    for lid, layer in proj.mapLayers().items()
                ],
                "modified": proj.isModified(),
            }
        return self.run_on_main_thread(_do)

    @staticmethod
    def _layer_type(layer) -> str:
        from qgis.core import QgsVectorLayer, QgsRasterLayer
        if isinstance(layer, QgsVectorLayer):
            return "vector"
        if isinstance(layer, QgsRasterLayer):
            return "raster"
        return "other"

    # ------------------------------------------------------------------ #
    # Layer inspection
    # ------------------------------------------------------------------ #
    def inspect_layers(self) -> dict:
        def _do():
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            layers = []
            for lid, layer in proj.mapLayers().items():
                info = {
                    "id": lid,
                    "name": layer.name(),
                    "type": self._layer_type(layer),
                    "valid": layer.isValid(),
                }
                if layer.crs().isValid():
                    info["crs"] = layer.crs().authid()
                try:
                    info["extent"] = [
                        layer.extent().xMinimum(), layer.extent().yMinimum(),
                        layer.extent().xMaximum(), layer.extent().yMaximum(),
                    ]
                except Exception:
                    info["extent"] = None
                if hasattr(layer, "featureCount"):
                    try:
                        info["feature_count"] = layer.featureCount()
                    except Exception:
                        info["feature_count"] = None
                if hasattr(layer, "width") and hasattr(layer, "height"):
                    info["width"] = layer.width()
                    info["height"] = layer.height()
                if hasattr(layer, "fields"):
                    info["fields"] = [f.name() for f in layer.fields()]
                layers.append(info)
            return {"layers": layers, "count": len(layers)}
        return self.run_on_main_thread(_do)

    # ------------------------------------------------------------------ #
    # Canvas inspection
    # ------------------------------------------------------------------ #
    def inspect_canvas(self) -> dict:
        def _do():
            canvas = self.iface.mapCanvas()
            return {
                "canvas_size": [canvas.size().width(), canvas.size().height()],
                "extent": [
                    canvas.extent().xMinimum(), canvas.extent().yMinimum(),
                    canvas.extent().xMaximum(), canvas.extent().yMaximum(),
                ],
                "crs": canvas.mapSettings().destinationCrs().authid(),
                "scale": canvas.scale(),
                "rotation": canvas.rotation(),
                "layers": [l.id() for l in canvas.layers()],
            }
        return self.run_on_main_thread(_do)

    # ------------------------------------------------------------------ #
    # Layer load
    # ------------------------------------------------------------------ #
    def load_layer(self, path: str, layer_name: str | None = None,
                   provider: str | None = None) -> dict:
        def _do():
            from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer
            layer = None
            if provider == "raster" or provider is None:
                rl = QgsRasterLayer(path, layer_name or path)
                if rl.isValid():
                    layer = rl
            if layer is None and (provider == "vector" or provider is None):
                vl = QgsVectorLayer(path, layer_name or path)
                if vl.isValid():
                    layer = vl
            if layer is None or not layer.isValid():
                raise ExecutionError(f"Failed to load layer: {path}")
            QgsProject.instance().addMapLayer(layer)
            crs = layer.crs()
            return {
                "id": layer.id(),
                "name": layer.name(),
                "type": self._layer_type(layer),
                "valid": layer.isValid(),
                "crs": crs.authid() if crs.isValid() else None,
            }
        return self.run_on_main_thread(_do)

    def remove_layer(self, layer_id: str) -> dict:
        def _do():
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            layer = proj.mapLayer(layer_id)
            if layer is None:
                raise ExecutionError(f"Layer not found: {layer_id}")
            proj.removeMapLayer(layer_id)
            return {"removed": True, "id": layer_id}
        return self.run_on_main_thread(_do)

    # ------------------------------------------------------------------ #
    # Screenshot
    # ------------------------------------------------------------------ #
    def capture_canvas(self) -> dict:
        """Capture the QGIS map canvas as a PNG. Returns base64 + size."""
        import base64
        from qgis.PyQt.QtGui import QImage

        def _do():
            canvas = self.iface.mapCanvas()
            img = QImage(canvas.size(), QImage.Format.Format_ARGB32)
            painter = None
            from qgis.PyQt.QtGui import QPainter
            painter = QPainter(img)
            canvas.render(painter)
            painter.end()
            ba = None
            from qgis.PyQt.QtCore import QBuffer, QByteArray
            ba = QByteArray()
            buf = QBuffer(ba)
            buf.open(QBuffer.OpenModeFlag.WriteOnly)
            img.save(buf, "PNG")
            b64 = base64.b64encode(bytes(ba.data())).decode("ascii")
            return {"image_base64": b64, "width": img.width(), "height": img.height(),
                    "format": "png"}
        return self.run_on_main_thread(_do)

    # ------------------------------------------------------------------ #
    # Algorithm execution
    # ------------------------------------------------------------------ #
    def execute_algorithm(self, algorithm_id: str, parameters: dict) -> dict:
        """Run a QGIS Processing algorithm. Returns outputs or raises."""
        def _do():
            import processing
            from qgis.core import QgsProcessingException
            try:
                result = processing.run(algorithm_id, parameters)
            except QgsProcessingException as exc:
                raise ExecutionError(str(exc)) from exc
            # Normalize outputs to serializable form
            out = {}
            for key, val in result.items():
                try:
                    out[key] = str(val)
                except Exception:
                    out[key] = repr(val)
            return {"outputs": out, "algorithm": algorithm_id}
        return self.run_on_main_thread(_do)

    # ------------------------------------------------------------------ #
    # Health
    # ------------------------------------------------------------------ #
    def health(self) -> dict:
        def _do():
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            return {
                "qgis_connected": True,
                "project_open": proj is not None,
                "layer_count": len(proj.mapLayers()),
                "main_thread": self._is_main_thread(),
            }
        return self.run_on_main_thread(_do)
