"""Universal AI GIS Studio — QGIS Bridge package.

Runs inside QGIS Desktop (in-process plugin). Exposes authenticated
localhost HTTP/IPC endpoints for the Universal MCP Server to drive
PyQGIS operations on the QGIS main thread.
"""

__version__ = "1.0.0"
