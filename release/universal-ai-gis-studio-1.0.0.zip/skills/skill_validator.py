"""Universal AI GIS Studio — Skill Validator.

Validates imported skills before execution. Untrusted skills are NOT granted
unrestricted shell, filesystem, or network access.
"""

import logging

from core.exceptions import SkillError

logger = logging.getLogger("uagis.skill_validator")


FORBIDDEN_KEYS = {"shell", "exec", "eval", "subprocess", "os.system",
                  "urllib", "requests", "socket", "ftplib"}


class SkillValidator:
    def validate(self, manifest: dict) -> list[str]:
        """Return list of validation problems (empty = valid)."""
        problems = []
        if not manifest.get("name"):
            problems.append("Missing skill name")
        if not manifest.get("version"):
            problems.append("Missing skill version")
        # Check for dangerous permissions
        perms = manifest.get("permissions", [])
        for p in perms:
            if p in ("shell:*", "filesystem:*", "network:*", "*"):
                problems.append(f"Overly broad permission: {p}")
        # Scan embedded code for forbidden calls
        code = manifest.get("code", "")
        lower = code.lower()
        for fk in FORBIDDEN_KEYS:
            if fk in lower:
                problems.append(f"Forbidden construct: {fk}")
        return problems

    def is_safe(self, manifest: dict) -> bool:
        return len(self.validate(manifest)) == 0


validator = SkillValidator()
