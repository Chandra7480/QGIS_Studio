"""Universal AI GIS Studio — Skill Loader."""

import json
import os
import logging
from typing import Optional

from skills.skill_validator import validator
from core.exceptions import SkillError

logger = logging.getLogger("uagis.skill_loader")


class SkillLoader:
    def load_from_directory(self, skill_dir: str) -> dict:
        manifest_path = os.path.join(skill_dir, "manifest.yaml")
        if not os.path.exists(manifest_path):
            manifest_path = os.path.join(skill_dir, "manifest.json")
        if os.path.exists(manifest_path):
            with open(manifest_path) as f:
                text = f.read()
            if manifest_path.endswith(".json"):
                manifest = json.loads(text)
            else:
                try:
                    import yaml
                    manifest = yaml.safe_load(text)
                except ImportError:
                    raise SkillError("PyYAML not installed; use manifest.json")
        else:
            raise SkillError(f"No manifest found in {skill_dir}")
        problems = validator.validate(manifest)
        if problems:
            raise SkillError(f"Skill validation failed: {', '.join(problems)}")
        return manifest
