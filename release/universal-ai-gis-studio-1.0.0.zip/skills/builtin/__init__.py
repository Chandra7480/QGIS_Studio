"""Built-in skills."""
