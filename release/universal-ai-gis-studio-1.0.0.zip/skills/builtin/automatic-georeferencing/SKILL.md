# Automatic Georeferencing Skill

Analyzes a scanned map image, detects landmarks via OpenCV (ORB/SIFT), generates
candidate Ground Control Points matched to a reference raster, validates them
(duplicates, outliers, residuals), and executes the transformation via QGIS/GDAL.

## Operations
- inspect_image
- detect_landmarks
- generate_gcps
- validate_gcps
- transform_with_qgis

## Security
No shell, filesystem (beyond declared inputs), or network access. Coordinates are
never invented; they come from the reference raster.