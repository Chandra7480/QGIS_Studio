"""Universal AI GIS Studio — Job Manager.

Manages the lifecycle of long-running jobs: creation, status updates,
cancellation, events, and persistence via JobRepository.
"""

import uuid
from datetime import datetime
from typing import Optional

from core.logging import get_logger
from core.exceptions import NotFoundError, ExecutionError
from database.repositories.job_repository import JobRepository

logger = get_logger("job_manager")


class JobManager:
    def __init__(self, db):
        self.repo = JobRepository(db)

    def create_job(self, job_type: str, input_payload: str = "{}",
                   agent_id: str | None = None, tool_id: str | None = None,
                   request_id: str | None = None) -> str:
        job_id = f"job_{uuid.uuid4().hex[:12]}"
        now = datetime.utcnow().isoformat()
        job = {
            "id": job_id,
            "type": job_type,
            "status": "queued",
            "agent_id": agent_id,
            "tool_id": tool_id,
            "request_id": request_id,
            "input_payload": input_payload,
            "output_payload": None,
            "verification_state": None,
            "started_at": None,
            "completed_at": None,
            "error_message": None,
        }
        self.repo.create(job)
        self.repo.add_event(job_id, "created", f"Job {job_type} created")
        logger.info("Job created: %s (%s)", job_id, job_type)
        return job_id

    def start_job(self, job_id: str) -> None:
        job = self.repo.get(job_id)
        if not job:
            raise NotFoundError(f"Job {job_id} not found")
        now = datetime.utcnow().isoformat()
        self.db().execute(
            "UPDATE jobs SET status = 'running', started_at = ? WHERE id = ?",
            (now, job_id),
        )
        self.repo.add_event(job_id, "started", "Job started")
        logger.info("Job started: %s", job_id)

    def complete_job(self, job_id: str, output_payload: str,
                     verification_state: str = "SUCCESS") -> None:
        job = self.repo.get(job_id)
        if not job:
            raise NotFoundError(f"Job {job_id} not found")
        self.repo.set_output(job_id, output_payload, verification_state)
        self.repo.add_event(job_id, "completed", f"Job completed (verification: {verification_state})")
        logger.info("Job completed: %s (verification=%s)", job_id, verification_state)

    def fail_job(self, job_id: str, error_message: str) -> None:
        job = self.repo.get(job_id)
        if not job:
            raise NotFoundError(f"Job {job_id} not found")
        now = datetime.utcnow().isoformat()
        self.db().execute(
            "UPDATE jobs SET status = 'failed', error_message = ?, completed_at = ? WHERE id = ?",
            (error_message, now, job_id),
        )
        self.repo.add_event(job_id, "failed", error_message)
        logger.error("Job failed: %s — %s", job_id, error_message)

    def cancel_job(self, job_id: str) -> None:
        job = self.repo.get(job_id)
        if not job:
            raise NotFoundError(f"Job {job_id} not found")
        self.repo.cancel(job_id)
        self.repo.add_event(job_id, "cancelled", "Job cancelled")
        logger.info("Job cancelled: %s", job_id)

    def get_job(self, job_id: str) -> dict:
        job = self.repo.get(job_id)
        if not job:
            raise NotFoundError(f"Job {job_id} not found")
        job["events"] = self.repo.get_events(job_id)
        return job

    def list_jobs(self, status: str | None = None, limit: int = 100) -> list:
        return self.repo.list(status=status, limit=limit)

    def db(self):
        return self.repo.db
