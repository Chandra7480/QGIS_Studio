"""Universal AI GIS Studio — Audit logging service."""

import logging

from database.repositories.audit_repository import AuditRepository

logger = logging.getLogger("uagis.monitoring.audit")


class AuditService:
    def __init__(self, db):
        self.repo = AuditRepository(db)

    def log(self, actor: str, action: str, target: str | None = None,
            outcome: str = "success", details: dict | None = None,
            ip: str | None = None) -> None:
        self.repo.log(actor, action, target, outcome, details, ip)
        logger.info("AUDIT %s %s %s %s", actor, action, target, outcome)

    def recent(self, limit: int = 50) -> list[dict]:
        return self.repo.list(limit=limit)
