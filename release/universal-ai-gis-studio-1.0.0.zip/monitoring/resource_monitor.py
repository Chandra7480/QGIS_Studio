"""Universal AI GIS Studio — Resource monitoring (low-resource laptop aware)."""

import logging
import shutil

logger = logging.getLogger("uagis.monitoring.resources")


class ResourceMonitor:
    def snapshot(self) -> dict:
        total, used, free = shutil.disk_usage(".")
        import os
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            class MEMORYSTATUS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("dwTotalPhys", ctypes.c_size_t),
                            ("dwAvailPhys", ctypes.c_size_t),
                            ("dwTotalPageFile", ctypes.c_size_t),
                            ("dwAvailPageFile", ctypes.c_size_t),
                            ("dwTotalVirtual", ctypes.c_size_t),
                            ("dwAvailVirtual", ctypes.c_size_t),
                            ("dwExtendedMemory", ctypes.c_size_t)]
            ms = MEMORYSTATUS()
            ms.dwLength = ctypes.sizeof(MEMORYSTATUS)
            kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
            mem = {"total": ms.dwTotalPhys, "available": ms.dwAvailPhys,
                   "load": ms.dwMemoryLoad}
        except Exception:
            mem = {"note": "memory info unavailable"}
        return {
            "disk": {"total": total, "used": used, "free": free},
            "memory": mem,
        }
