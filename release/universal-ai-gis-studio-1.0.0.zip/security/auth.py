"""Universal AI GIS Studio — Bridge Authentication.

Authenticated localhost IPC for the QGIS Bridge. Token-based.
"""

import logging

logger = logging.getLogger("uagis.security.auth")


class BridgeAuth:
    def __init__(self, token: str | None = None):
        self.token = token

    def required(self) -> bool:
        return self.token is not None

    def validate(self, provided: str | None) -> bool:
        if self.token is None:
            return True  # auth not configured
        return provided == self.token
