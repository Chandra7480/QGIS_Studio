"""External MCP server management."""
