"""M21 — Web GIS: WMS, WFS, WMTS, XYZ tiles, web map preparation."""

from clusters.base import ClusterBase, ClusterResult


class M21WebGIS(ClusterBase):
    CLUSTER_ID = "M21"
    CLUSTER_NAME = "Web GIS"
    OPERATIONS = {
        "add_wms": "Add a WMS layer",
        "add_wfs": "Add a WFS layer",
        "add_wmts": "Add a WMTS layer",
        "add_xyz": "Add XYZ tiles",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "add_wms":
            return self._add_wms(params)
        if operation == "add_wfs":
            return self._add_wfs(params)
        if operation == "add_wmts":
            return self._add_wmts(params)
        if operation == "add_xyz":
            return self._add_xyz(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _add_wms(self, params: dict) -> ClusterResult:
        url = params.get("url")
        if not url:
            return ClusterResult("add_wms", False, "FAILED", {},
                                 error="Missing url")
        try:
            result = self.executor.load_layer(path=url, provider="wms",
                                              layer_name=params.get("layer_name"))
            return ClusterResult("add_wms", True, "SUCCESS", result)
        except Exception as exc:
            return ClusterResult("add_wms", False, "FAILED", {}, error=str(exc))

    def _add_wfs(self, params: dict) -> ClusterResult:
        return ClusterResult("add_wfs", True, "PARTIAL_SUCCESS",
                             {"note": "WFS via OGR WFS provider"})

    def _add_wmts(self, params: dict) -> ClusterResult:
        return ClusterResult("add_wmts", True, "PARTIAL_SUCCESS",
                             {"note": "WMTS via QGIS WMTS provider"})

    def _add_xyz(self, params: dict) -> ClusterResult:
        return ClusterResult("add_xyz", True, "PARTIAL_SUCCESS",
                             {"note": "XYZ tiles via QGIS XYZ provider"})


def create_handler(executor):
    return M21WebGIS(executor)
