"""M15 — LiDAR: point-cloud inspection, filtering, classification, terrain extraction."""

from clusters.base import ClusterBase, ClusterResult


_ALGO_MAP = {
    "point_cloud_inspection": ["native:zonalstatistics"],
    "filtering": ["native:extractbyattribute"],
    "classification": ["native:reclassifybytable"],
    "terrain_extraction": ["gdal:dem", "native:dem"],
}


class M15LiDAR(ClusterBase):
    CLUSTER_ID = "M15"
    CLUSTER_NAME = "LiDAR"
    OPERATIONS = {k: f"LiDAR {k}" for k in _ALGO_MAP}

    def execute(self, operation: str, params: dict) -> ClusterResult:
        patterns = _ALGO_MAP.get(operation)
        if not patterns:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"Unknown operation: {operation}")
        algo = self.discover_algorithm(patterns)
        if not algo:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"No processing algorithm found for {operation}")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult(operation, True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=str(exc))


def create_handler(executor):
    return M15LiDAR(executor)
