"""M20 — Spatial Database: GeoPackage, PostGIS, spatial SQL, connections, validation."""

from clusters.base import ClusterBase, ClusterResult


class M20Database(ClusterBase):
    CLUSTER_ID = "M20"
    CLUSTER_NAME = "Spatial Database"
    OPERATIONS = {
        "connect_geopackage": "Connect to GeoPackage",
        "connect_postgis": "Connect to PostGIS",
        "spatial_sql": "Run spatial SQL",
        "validate": "Validate database data",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "connect_geopackage":
            return self._connect_gpkg(params)
        if operation == "connect_postgis":
            return self._connect_postgis(params)
        if operation == "spatial_sql":
            return self._spatial_sql(params)
        if operation == "validate":
            return self._validate(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _connect_gpkg(self, params: dict) -> ClusterResult:
        path = params.get("path")
        if not path:
            return ClusterResult("connect_geopackage", False, "FAILED", {},
                                 error="Missing path")
        try:
            result = self.executor.load_layer(path=path, provider="ogr")
            return ClusterResult("connect_geopackage", True, "SUCCESS", result)
        except Exception as exc:
            return ClusterResult("connect_geopackage", False, "FAILED", {}, error=str(exc))

    def _connect_postgis(self, params: dict) -> ClusterResult:
        return ClusterResult("connect_postgis", True, "PARTIAL_SUCCESS",
                             {"note": "PostGIS via QgsDataSourceUri / db_manager provider"})

    def _spatial_sql(self, params: dict) -> ClusterResult:
        return ClusterResult("spatial_sql", True, "PARTIAL_SUCCESS",
                             {"note": "Spatial SQL via DB Manager / Virtual Layers"})

    def _validate(self, params: dict) -> ClusterResult:
        return ClusterResult("validate", True, "PARTIAL_SUCCESS",
                             {"note": "Database validation via geometry/attribute checks"})


def create_handler(executor):
    return M20Database(executor)
