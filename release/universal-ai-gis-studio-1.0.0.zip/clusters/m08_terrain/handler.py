"""M08 — Terrain Analysis: DEM, slope, aspect, hillshade, contours, derivatives."""

from clusters.base import ClusterBase, ClusterResult


_ALGO_MAP = {
    "slope": ["native:slope", "gdal:slope"],
    "aspect": ["native:aspect", "gdal:aspect"],
    "hillshade": ["native:hillshade", "gdal:hillshade"],
    "contours": ["native:contour", "gdal:contour"],
    "terrain_derivatives": ["native:roughness", "gdal:dem"],
    "dem_processing": ["gdal:dem"],
}


class M08Terrain(ClusterBase):
    CLUSTER_ID = "M08"
    CLUSTER_NAME = "Terrain Analysis"
    OPERATIONS = {k: f"Terrain {k}" for k in _ALGO_MAP}

    def execute(self, operation: str, params: dict) -> ClusterResult:
        patterns = _ALGO_MAP.get(operation)
        if not patterns:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"Unknown operation: {operation}")
        algo = self.discover_algorithm(patterns)
        if not algo:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"No processing algorithm found for {operation}")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult(operation, True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=str(exc))


def create_handler(executor):
    return M08Terrain(executor)
