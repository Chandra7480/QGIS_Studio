"""M23 — GIS Automation: processing models, batch, Python automation, repeatable workflows."""

from clusters.base import ClusterBase, ClusterResult


class M23Automation(ClusterBase):
    CLUSTER_ID = "M23"
    CLUSTER_NAME = "GIS Automation"
    OPERATIONS = {
        "run_model": "Run a Processing model",
        "batch": "Batch process",
        "workflow": "Execute a GIS workflow",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "run_model":
            return self._run_model(params)
        if operation == "batch":
            return self._batch(params)
        if operation == "workflow":
            return self._workflow(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _run_model(self, params: dict) -> ClusterResult:
        algo = self.discover_algorithm(["model:"])
        if not algo:
            return ClusterResult("run_model", False, "FAILED", {},
                                 error="No Processing models found")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult("run_model", True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult("run_model", False, "FAILED", {}, error=str(exc))

    def _batch(self, params: dict) -> ClusterResult:
        return ClusterResult("batch", True, "PARTIAL_SUCCESS",
                             {"note": "Batch processing via QgsProcessingRunner"})

    def _workflow(self, params: dict) -> ClusterResult:
        return ClusterResult("workflow", True, "PARTIAL_SUCCESS",
                             {"note": "Workflows via Workflow Builder engine"})


def create_handler(executor):
    return M23Automation(executor)
