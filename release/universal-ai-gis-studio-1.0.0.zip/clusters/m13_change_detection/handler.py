"""M13 — Change Detection: temporal comparison, raster difference, land-cover change, reports."""

from clusters.base import ClusterBase, ClusterResult


_ALGO_MAP = {
    "temporal_comparison": ["native:rastercalculator"],
    "raster_difference": ["native:rastercalculator"],
    "landcover_change": ["native:rastercalculator"],
    "change_report": ["native:zonalstatistics"],
}


class M13ChangeDetection(ClusterBase):
    CLUSTER_ID = "M13"
    CLUSTER_NAME = "Change Detection"
    OPERATIONS = {k: f"Change Detection {k}" for k in _ALGO_MAP}

    def execute(self, operation: str, params: dict) -> ClusterResult:
        patterns = _ALGO_MAP.get(operation)
        if not patterns:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"Unknown operation: {operation}")
        algo = self.discover_algorithm(patterns)
        if not algo:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"No processing algorithm found for {operation}")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult(operation, True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=str(exc))


def create_handler(executor):
    return M13ChangeDetection(executor)
