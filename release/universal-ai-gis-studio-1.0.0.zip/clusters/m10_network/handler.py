"""M10 — Network Analysis: shortest path, service areas, routing, connectivity."""

from clusters.base import ClusterBase, ClusterResult


_ALGO_MAP = {
    "shortest_path": ["native:shortestpathpointtopoint", "native:shortestpath"],
    "service_areas": ["native:servicearea", "native:serviceareaisochrones"],
    "routing": ["native:shortestpathpointtopoint"],
    "connectivity": ["native:shortestpathpointtopoint"],
}


class M10Network(ClusterBase):
    CLUSTER_ID = "M10"
    CLUSTER_NAME = "Network Analysis"
    OPERATIONS = {k: f"Network {k}" for k in _ALGO_MAP}

    def execute(self, operation: str, params: dict) -> ClusterResult:
        patterns = _ALGO_MAP.get(operation)
        if not patterns:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"Unknown operation: {operation}")
        algo = self.discover_algorithm(patterns)
        if not algo:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"No processing algorithm found for {operation}")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult(operation, True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=str(exc))


def create_handler(executor):
    return M10Network(executor)
