"""M14 — 3D GIS: 3D visualization, terrain models, 3D layers, 3D exports where supported."""

from clusters.base import ClusterBase, ClusterResult


class M14_3D(ClusterBase):
    CLUSTER_ID = "M14"
    CLUSTER_NAME = "3D GIS"
    OPERATIONS = {
        "inspect_3d": "Inspect 3D capabilities",
        "create_terrain_model": "Create a terrain model (DEM-based)",
        "export_3d": "Export to 3D where supported",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "inspect_3d":
            return self._inspect_3d(params)
        if operation == "create_terrain_model":
            return self._create_terrain(params)
        if operation == "export_3d":
            return self._export_3d(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _inspect_3d(self, params: dict) -> ClusterResult:
        try:
            has3d = bool(self.executor.iface.mapCanvas().settings().showCursorPos)
        except Exception:
            has3d = False
        return ClusterResult("inspect_3d", True, "SUCCESS",
                             {"three_d_available": bool(has3d),
                              "note": "3D depends on QGIS build and plugin"})

    def _create_terrain(self, params: dict) -> ClusterResult:
        algo = self.discover_algorithm(["native:dem", "gdal:dem"])
        if not algo:
            return ClusterResult("create_terrain_model", False, "FAILED", {},
                                 error="No DEM/terrain algorithm available")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult("create_terrain_model", True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult("create_terrain_model", False, "FAILED", {},
                                 error=str(exc))

    def _export_3d(self, params: dict) -> ClusterResult:
        return ClusterResult("export_3d", True, "PARTIAL_SUCCESS",
                             {"note": "3D export requires QGIS 3D view; not universally supported"},
                             error=None)


def create_handler(executor):
    return M14_3D(executor)
