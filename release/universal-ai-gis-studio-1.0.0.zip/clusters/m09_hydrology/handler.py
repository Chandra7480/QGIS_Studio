"""M09 — Hydrological Analysis: flow direction, accumulation, watershed, streams, drainage."""

from clusters.base import ClusterBase, ClusterResult


_ALGO_MAP = {
    "flow_direction": ["grass:r.watershed", "native:flowdirection"],
    "flow_accumulation": ["grass:r.watershed", "native:flowaccumulation"],
    "watershed": ["grass:r.watershed", "native:watershed"],
    "stream_extraction": ["native:streamextraction"],
    "drainage_network": ["grass:r.watershed"],
}


class M09Hydrology(ClusterBase):
    CLUSTER_ID = "M09"
    CLUSTER_NAME = "Hydrological Analysis"
    OPERATIONS = {k: f"Hydrology {k}" for k in _ALGO_MAP}

    def execute(self, operation: str, params: dict) -> ClusterResult:
        patterns = _ALGO_MAP.get(operation)
        if not patterns:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"Unknown operation: {operation}")
        algo = self.discover_algorithm(patterns)
        if not algo:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"No processing algorithm found for {operation}")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult(operation, True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=str(exc))


def create_handler(executor):
    return M09Hydrology(executor)
