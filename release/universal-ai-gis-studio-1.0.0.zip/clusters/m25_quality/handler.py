"""M25 — Quality Control: geometry, topology, CRS, attribute, completeness, reports."""

from clusters.base import ClusterBase, ClusterResult


_ALGO_MAP = {
    "geometry_validation": ["native:checkvalidity", "native:fixgeometries"],
    "topology_validation": ["native:checkvalidity"],
    "crs_validation": ["native:assigncrs"],
    "attribute_validation": ["native:fieldcalculator"],
    "completeness": ["native:zonalstatistics"],
}


class M25Quality(ClusterBase):
    CLUSTER_ID = "M25"
    CLUSTER_NAME = "Quality Control"
    OPERATIONS = {k: f"Quality {k}" for k in _ALGO_MAP}

    def execute(self, operation: str, params: dict) -> ClusterResult:
        patterns = _ALGO_MAP.get(operation)
        if not patterns:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"Unknown operation: {operation}")
        algo = self.discover_algorithm(patterns)
        if not algo:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"No processing algorithm found for {operation}")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult(operation, True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=str(exc))


def create_handler(executor):
    return M25Quality(executor)
