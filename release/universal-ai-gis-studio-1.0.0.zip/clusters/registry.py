"""Cluster registry: maps M01-M25 to their handler modules."""

import importlib

CLUSTER_MODULES = {
    "M01": "clusters.m01_data_acquisition",
    "M02": "clusters.m02_data_management",
    "M03": "clusters.m03_vector",
    "M04": "clusters.m04_raster",
    "M05": "clusters.m05_georeferencing",
    "M06": "clusters.m06_crs",
    "M07": "clusters.m07_spatial",
    "M08": "clusters.m08_terrain",
    "M09": "clusters.m09_hydrology",
    "M10": "clusters.m10_network",
    "M11": "clusters.m11_remote_sensing",
    "M12": "clusters.m12_classification",
    "M13": "clusters.m13_change_detection",
    "M14": "clusters.m14_3d",
    "M15": "clusters.m15_lidar",
    "M16": "clusters.m16_survey",
    "M17": "clusters.m17_cadastral",
    "M18": "clusters.m18_cartography",
    "M19": "clusters.m19_temporal",
    "M20": "clusters.m20_database",
    "M21": "clusters.m21_web_gis",
    "M22": "clusters.m22_field_data",
    "M23": "clusters.m23_automation",
    "M24": "clusters.m24_ai_ml",
    "M25": "clusters.m25_quality",
}


def get_cluster_handler(cluster_id: str, executor):
    mod_base = CLUSTER_MODULES.get(cluster_id)
    if not mod_base:
        from core.exceptions import NotFoundError
        raise NotFoundError(f"Unknown cluster: {cluster_id}")
    mod_name = mod_base + ".handler"
    mod = importlib.import_module(mod_name)
    handler = mod.create_handler(executor)
    return handler
