"""M12 — Image Classification: workflows, training data, accuracy, outputs."""

from clusters.base import ClusterBase, ClusterResult


_ALGO_MAP = {
    "classify": ["native:reclassifybytable"],
    "train": ["native:reclassifybytable"],
    "accuracy": ["native:zonalstatistics"],
    "output": ["gdal:translate"],
}


class M12Classification(ClusterBase):
    CLUSTER_ID = "M12"
    CLUSTER_NAME = "Image Classification"
    OPERATIONS = {k: f"Classification {k}" for k in _ALGO_MAP}

    def execute(self, operation: str, params: dict) -> ClusterResult:
        patterns = _ALGO_MAP.get(operation)
        if not patterns:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"Unknown operation: {operation}")
        algo = self.discover_algorithm(patterns)
        if not algo:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=f"No processing algorithm found for {operation}")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult(operation, True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult(operation, False, "FAILED", {},
                                 error=str(exc))


def create_handler(executor):
    return M12Classification(executor)
