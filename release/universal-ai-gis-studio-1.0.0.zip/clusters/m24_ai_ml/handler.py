"""M24 — AI-Assisted GIS: external AI analysis, image interpretation, NL ops, reasoning.

This cluster does NOT include a bundled or mandatory local AI model. AI is supplied
externally (OpenCode / Codex / optional API). This cluster orchestrates calls to
external AI via the AI Host Manager and verifies results locally.
"""

from clusters.base import ClusterBase, ClusterResult


class M24AIML(ClusterBase):
    CLUSTER_ID = "M24"
    CLUSTER_NAME = "AI-Assisted GIS"
    OPERATIONS = {
        "external_analysis": "Request external AI-assisted analysis",
        "image_interpretation": "Request external image interpretation",
        "natural_language_op": "Natural language GIS operation (orchestrated)",
        "ai_validation": "AI-assisted data validation",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "external_analysis":
            return self._external_analysis(params)
        if operation == "image_interpretation":
            return self._image_interpretation(params)
        if operation == "natural_language_op":
            return self._natural_language_op(params)
        if operation == "ai_validation":
            return self._ai_validation(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _external_analysis(self, params: dict) -> ClusterResult:
        return ClusterResult("external_analysis", True, "PARTIAL_SUCCESS",
                             {"note": "Delegated to external AI host via AI Host Manager; no bundled model"})

    def _image_interpretation(self, params: dict) -> ClusterResult:
        return ClusterResult("image_interpretation", True, "PARTIAL_SUCCESS",
                             {"note": "Requires a vision-capable external AI host; screenshot-based"})

    def _natural_language_op(self, params: dict) -> ClusterResult:
        return ClusterResult("natural_language_op", True, "PARTIAL_SUCCESS",
                             {"note": "Orchestrated through the Agent Orchestrator"})

    def _ai_validation(self, params: dict) -> ClusterResult:
        return ClusterResult("ai_validation", True, "PARTIAL_SUCCESS",
                             {"note": "AI suggestions verified locally by the Verification Engine"})


def create_handler(executor):
    return M24AIML(executor)
