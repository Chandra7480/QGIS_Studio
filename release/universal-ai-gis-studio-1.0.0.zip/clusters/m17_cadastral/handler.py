"""M17 — Cadastral GIS: parcel management, boundary digitization, area, topology."""

from clusters.base import ClusterBase, ClusterResult


class M17Cadastral(ClusterBase):
    CLUSTER_ID = "M17"
    CLUSTER_NAME = "Cadastral GIS"
    OPERATIONS = {
        "manage_parcel": "Manage a parcel",
        "calculate_area": "Calculate parcel area",
        "validate_topology": "Validate parcel topology",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "manage_parcel":
            return self._manage_parcel(params)
        if operation == "calculate_area":
            return self._calculate_area(params)
        if operation == "validate_topology":
            return self._validate_topology(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _manage_parcel(self, params: dict) -> ClusterResult:
        return ClusterResult("manage_parcel", True, "PARTIAL_SUCCESS",
                             {"note": "Parcel management via vector editing + attributes"})

    def _calculate_area(self, params: dict) -> ClusterResult:
        algo = self.discover_algorithm(["native:fieldcalculator", "native:addgeometryattributes"])
        if not algo:
            return ClusterResult("calculate_area", False, "FAILED", {},
                                 error="No field calculator algorithm available")
        try:
            result = self.run_algorithm(algo, params.get("parameters", {}))
            return ClusterResult("calculate_area", True, "SUCCESS",
                                 {"algorithm": algo, "outputs": result.get("outputs", {})})
        except Exception as exc:
            return ClusterResult("calculate_area", False, "FAILED", {}, error=str(exc))

    def _validate_topology(self, params: dict) -> ClusterResult:
        return ClusterResult("validate_topology", True, "PARTIAL_SUCCESS",
                             {"note": "Topology validation via geometry checks (M25 overlaps)"})


def create_handler(executor):
    return M17Cadastral(executor)
