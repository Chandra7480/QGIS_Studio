"""M16 — Survey and GPS: GPS import, coord validation, survey handling, points/tracks."""

from clusters.base import ClusterBase, ClusterResult


class M16Survey(ClusterBase):
    CLUSTER_ID = "M16"
    CLUSTER_NAME = "Survey and GPS"
    OPERATIONS = {
        "import_gps": "Import GPS data",
        "validate_coords": "Validate coordinates",
        "process_tracks": "Process GPS tracks",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "import_gps":
            return self._import_gps(params)
        if operation == "validate_coords":
            return self._validate_coords(params)
        if operation == "process_tracks":
            return self._process_tracks(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _import_gps(self, params: dict) -> ClusterResult:
        path = params.get("path")
        if not path:
            return ClusterResult("import_gps", False, "FAILED", {},
                                 error="Missing path")
        try:
            result = self.executor.load_layer(path=path, provider="vector")
            return ClusterResult("import_gps", True, "SUCCESS", result)
        except Exception as exc:
            return ClusterResult("import_gps", False, "FAILED", {}, error=str(exc))

    def _validate_coords(self, params: dict) -> ClusterResult:
        x = params.get("x"); y = params.get("y")
        ok = isinstance(x, (int, float)) and isinstance(y, (int, float))
        return ClusterResult("validate_coords", ok, "SUCCESS" if ok else "FAILED",
                             {"x": x, "y": y, "valid": ok})

    def _process_tracks(self, params: dict) -> ClusterResult:
        return ClusterResult("process_tracks", True, "PARTIAL_SUCCESS",
                             {"note": "Track processing depends on GPS data format support"})


def create_handler(executor):
    return M16Survey(executor)
