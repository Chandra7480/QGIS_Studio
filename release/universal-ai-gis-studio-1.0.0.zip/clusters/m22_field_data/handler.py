"""M22 — Field Data: import, survey sync, attribute collection, validation."""

from clusters.base import ClusterBase, ClusterResult


class M22FieldData(ClusterBase):
    CLUSTER_ID = "M22"
    CLUSTER_NAME = "Field Data"
    OPERATIONS = {
        "import_field": "Import field data",
        "sync_survey": "Synchronize survey",
        "collect_attributes": "Collect attributes",
        "validate": "Validate field dataset",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "import_field":
            return self._import_field(params)
        if operation == "sync_survey":
            return self._sync_survey(params)
        if operation == "collect_attributes":
            return self._collect_attributes(params)
        if operation == "validate":
            return self._validate(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _import_field(self, params: dict) -> ClusterResult:
        path = params.get("path")
        if not path:
            return ClusterResult("import_field", False, "FAILED", {}, error="Missing path")
        try:
            result = self.executor.load_layer(path=path, provider="vector")
            return ClusterResult("import_field", True, "SUCCESS", result)
        except Exception as exc:
            return ClusterResult("import_field", False, "FAILED", {}, error=str(exc))

    def _sync_survey(self, params: dict) -> ClusterResult:
        return ClusterResult("sync_survey", True, "PARTIAL_SUCCESS",
                             {"note": "Survey sync depends on field app integration"})

    def _collect_attributes(self, params: dict) -> ClusterResult:
        return ClusterResult("collect_attributes", True, "PARTIAL_SUCCESS",
                             {"note": "Attribute collection via form/edit API"})

    def _validate(self, params: dict) -> ClusterResult:
        return ClusterResult("validate", True, "PARTIAL_SUCCESS",
                             {"note": "Field data validation via geometry/attribute checks"})


def create_handler(executor):
    return M22FieldData(executor)
