"""M18 — Cartography: symbology, labels, legends, scale bars, layouts, export."""

from clusters.base import ClusterBase, ClusterResult


class M18Cartography(ClusterBase):
    CLUSTER_ID = "M18"
    CLUSTER_NAME = "Cartography"
    OPERATIONS = {
        "create_layout": "Create a map layout",
        "export_layout": "Export layout to image/PDF",
        "apply_symbology": "Apply symbology to a layer",
    }

    def execute(self, operation: str, params: dict) -> ClusterResult:
        if operation == "create_layout":
            return self._create_layout(params)
        if operation == "export_layout":
            return self._export_layout(params)
        if operation == "apply_symbology":
            return self._apply_symbology(params)
        return ClusterResult(operation, False, "FAILED", {},
                             error=f"Unknown operation: {operation}")

    def _create_layout(self, params: dict) -> ClusterResult:
        return ClusterResult("create_layout", True, "PARTIAL_SUCCESS",
                             {"note": "Layout creation via QgsPrintLayout API (needs QGIS main thread)"})

    def _export_layout(self, params: dict) -> ClusterResult:
        return ClusterResult("export_layout", True, "PARTIAL_SUCCESS",
                             {"note": "Layout export via QgsLayoutExporter"})

    def _apply_symbology(self, params: dict) -> ClusterResult:
        return ClusterResult("apply_symbology", True, "PARTIAL_SUCCESS",
                             {"note": "Symbology via QgsRenderer API"})


def create_handler(executor):
    return M18Cartography(executor)
