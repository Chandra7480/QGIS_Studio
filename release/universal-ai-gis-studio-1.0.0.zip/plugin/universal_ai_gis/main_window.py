"""Universal AI GIS Studio — Main plugin window (dock widget content).

Placeholder shell for the 19-panel UI. Panels are implemented progressively
across stages. Uses PyQt6 (Qt6, matching QGIS 4.x).
"""

from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem, QLabel,
    QStackedWidget, QSplitter, QHBoxLayout,
)
from qgis.PyQt.QtCore import Qt


class UniversalAIGISMainWindow(QWidget):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._build_ui()

    def _build_ui(self):
        outer = QHBoxLayout(self)

        # Left: section navigator
        self.nav = QTreeWidget()
        self.nav.setHeaderHidden(True)
        self.nav.setMaximumWidth(240)
        sections = [
            "Dashboard", "AI Chat", "Live Screen", "AI Cursor",
            "AI Connections", "API Providers", "MCP Manager", "Agent Manager",
            "Skill Manager", "GIS Clusters", "Georeferencing", "GCP Intelligence",
            "Workflow Builder", "Algorithm Discovery", "Data Manager",
            "Quality Control", "Task History", "Security", "Settings",
        ]
        for s in sections:
            QTreeWidgetItem(self.nav, [s])

        # Right: stacked content (placeholder labels per section)
        self.stack = QStackedWidget()
        for s in sections:
            w = QLabel(f"{s} panel — implementation in progress")
            w.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.stack.addWidget(w)

        self.nav.currentItemChanged.connect(self._on_nav)

        splitter = QSplitter()
        splitter.addWidget(self.nav)
        splitter.addWidget(self.stack)
        splitter.setStretchFactor(1, 1)

        outer.addWidget(splitter)
        self.nav.setCurrentItem(self.nav.topLevelItem(0))

    def _on_nav(self, current, previous):
        if current is None:
            return
        idx = self.nav.indexOfTopLevelItem(current)
        self.stack.setCurrentIndex(idx)
