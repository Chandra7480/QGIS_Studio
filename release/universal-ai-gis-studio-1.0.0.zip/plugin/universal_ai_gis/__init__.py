"""Universal AI GIS Studio - QGIS Plugin package."""

__version__ = "1.0.0"

from .plugin import UniversalAIGISPlugin  # noqa: E402


def classFactory(iface):  # QGIS plugin entry point
    """Instantiate the Universal AI GIS Studio plugin."""
    return UniversalAIGISPlugin(iface)
