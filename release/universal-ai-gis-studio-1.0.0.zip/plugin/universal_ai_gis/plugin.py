"""Universal AI GIS Studio — QGIS plugin entry point.

Loads the QGIS Bridge (localhost HTTP server) and the plugin dock UI.
Runs inside QGIS Desktop so PyQGIS GUI operations execute on the main thread.
"""

import os
import sys

# Add project root (parent of this plugin package) to sys.path so that
# bridge.*, core.*, database.*, etc. can be imported inside QGIS.
_PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(os.path.dirname(_PLUGIN_DIR))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from qgis.PyQt.QtWidgets import QAction, QDockWidget
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject

from bridge.executor import PyQGISExecutor
from bridge.dispatcher import BridgeDispatcher
from bridge.bridge_server import BridgeServer
from core.logging import setup_logging, get_logger
from core.config import Config
from core.job_manager import JobManager
from database.db import Database
from database.schema import initialize as init_schema

logger = get_logger("uagis.plugin")


class UniversalAIGISPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.bridge_server = None
        self.dock_widget = None
        self.action = None
        self.db = None
        self.job_manager = None
        self.executor = None
        self.dispatcher = None

    def initGui(self):
        try:
            self._init_core()
            self._start_bridge()
            self._create_ui()
            logger.info("Universal AI GIS Studio plugin loaded")
        except Exception as exc:
            logger.exception("Failed to initialize plugin: %s", exc)
            raise

    def _init_core(self):
        # Configuration
        config = Config()
        config.set("qgis_install_path", self._locate_qgis_install(), persist=False)
        config.set("qgis_python_exe", sys.executable, persist=False)

        # Data dir + database
        data_dir = config.get("data_dir") or self._default_data_dir()
        config.set("data_dir", data_dir, persist=False)
        config.set("log_dir", os.path.join(data_dir, "logs"), persist=False)
        os.makedirs(config.get("log_dir"), exist_ok=True)

        setup_logging(config.get("log_dir"))
        logger.info("Core initialized; data_dir=%s", data_dir)

        db_path = os.path.join(data_dir, "uagis.db")
        self.db = Database(db_path)
        from database.schema import initialize as init_schema
        init_schema(self.db)

        self.job_manager = JobManager(self.db)
        self.executor = PyQGISExecutor(self.iface)
        self.dispatcher = BridgeDispatcher(self.executor)

    def _start_bridge(self):
        config = Config()
        host = config.get("bridge_host")
        port = config.get("bridge_port")
        token = config.get("bridge_auth_token") or None
        self.bridge_server = BridgeServer(host=host, port=port, auth_token=token)
        self.bridge_server.start(self.dispatcher)

    def _create_ui(self):
        # Dock widget placeholder — UI modules implemented in Stage 2+
        self.dock_widget = QDockWidget("Universal AI GIS Studio", self.iface.mainWindow())
        self.dock_widget.setObjectName("uagisDock")
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock_widget)

        # Toolbar action
        self.action = QAction(QIcon(), "Universal AI GIS Studio", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.setChecked(True)
        self.action.triggered.connect(self._toggle_dock)
        self.iface.addToolBarIcon(self.action)

    def _toggle_dock(self, checked):
        if self.dock_widget:
            self.dock_widget.setVisible(checked)

    def _locate_qgis_install(self):
        # Heuristic: QGIS prefix path
        from qgis.core import QgsApplication
        return QgsApplication.prefixPath()

    def _default_data_dir(self):
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(base, "Universal AI GIS Studio")

    def unload(self):
        try:
            if self.action:
                self.iface.removeToolBarIcon(self.action)
            if self.dock_widget:
                self.iface.removeDockWidget(self.dock_widget)
            if self.bridge_server:
                self.bridge_server.stop()
            if self.db:
                self.db.close()
            logger.info("Universal AI GIS Studio plugin unloaded")
        except Exception as exc:
            logger.exception("Error during plugin unload: %s", exc)


# Qt import needed for dock area
from qgis.PyQt.QtCore import Qt  # noqa: E402


def classFactory(iface):  # QGIS plugin entry point
    """Instantiate the Universal AI GIS Studio plugin."""
    return UniversalAIGISPlugin(iface)
