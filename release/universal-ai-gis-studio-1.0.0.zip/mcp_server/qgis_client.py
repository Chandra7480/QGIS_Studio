"""Universal AI GIS Studio — QGIS Bridge HTTP client.

Talks to the QGIS Bridge (localhost HTTP) from the MCP server.
Adds auth header, request IDs, timeouts, and structured error handling.
"""

import json
import urllib.request
import urllib.error
from typing import Optional

from core.logging import get_logger
from core.exceptions import BridgeError, UAGISTimeoutError, MCPError

logger = get_logger("mcp.qgis_client")


class QgisBridgeClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8765",
                 auth_token: Optional[str] = None,
                 timeout_seconds: int = 300):
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self.timeout_seconds = timeout_seconds

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers

    def dispatch(self, tool: str, params: dict, request_id: str,
                 timeout_seconds: Optional[int] = None) -> dict:
        """Send a dispatch request to the bridge and return the response dict."""
        payload = {
            "request_id": request_id,
            "tool": tool,
            "params": params,
            "timeout_seconds": timeout_seconds or self.timeout_seconds,
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/dispatch",
            data=data,
            headers=self._headers(),
            method="POST",
        )
        timeout = timeout_seconds or self.timeout_seconds
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body) if body else {}
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read().decode("utf-8")
                detail = json.loads(body) if body else {}
            except Exception:
                detail = {"code": "HTTP_ERROR", "message": str(exc)}
            raise BridgeError(
                f"Bridge HTTP {exc.code} for {tool}: {detail.get('message', str(exc))}",
                context={"http_status": exc.code, "detail": detail},
            ) from exc
        except urllib.error.URLError as exc:
            raise BridgeError(f"Bridge unreachable at {self.base_url}: {exc}") from exc
        except Exception as exc:
            raise BridgeError(f"Bridge dispatch failed for {tool}: {exc}") from exc

    def health(self) -> dict:
        try:
            req = urllib.request.Request(
                f"{self.base_url}/health", headers=self._headers(), method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except Exception as exc:
            return {"qgis_connected": False, "error": str(exc)}
