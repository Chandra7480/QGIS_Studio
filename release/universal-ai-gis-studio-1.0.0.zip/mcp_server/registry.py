"""Universal AI GIS Studio — MCP Tool Registry.

Defines every MCP tool as a typed ToolSpec: name, namespace, description,
strict input/output JSON schemas, permission requirements, timeout, and
verification rules. The registry is the single source of truth for what
the MCP server exposes.
"""

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ToolSpec:
    name: str                      # e.g. "qgis.system.inspect"
    namespace: str                 # e.g. "qgis.system"
    description: str
    input_schema: dict             # JSON Schema (strict)
    output_schema: dict            # JSON Schema
    permissions: list[str] = field(default_factory=list)
    timeout_seconds: int = 300
    require_approval: bool = False
    verification_rules: list[str] = field(default_factory=list)

    def to_mcp_tool(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec) -> None:
        self._tools[spec.name] = spec

    def get(self, name: str) -> Optional[ToolSpec]:
        return self._tools.get(name)

    def all(self) -> list[ToolSpec]:
        return list(self._tools.values())

    def names(self) -> list[str]:
        return sorted(self._tools.keys())

    def namespaces(self) -> list[str]:
        return sorted({t.namespace for t in self._tools.values()})


# --------------------------------------------------------------------------- #
# Common schema fragments
# --------------------------------------------------------------------------- #
_STR = {"type": "string"}
_OBJ = {"type": "object"}
_ARR = {"type": "array"}


def _str_prop(desc: str = "value") -> dict:
    return {"type": "string", "description": desc}


def _bool_prop(desc: str = "value") -> dict:
    return {"type": "boolean", "description": desc}


def _int_prop(desc: str = "value") -> dict:
    return {"type": "integer", "description": desc}


def _num_prop(desc: str = "value") -> dict:
    return {"type": "number", "description": desc}


def _list_prop(desc: str = "value", item_type: str = "string") -> dict:
    return {"type": "array", "description": desc, "items": {"type": item_type}}


def base_input(required: list[str] | None = None, properties: dict | None = None) -> dict:
    props = properties or {}
    req = required or []
    return {
        "type": "object",
        "properties": props,
        "required": req,
        "additionalProperties": False,
    }


def base_output(props: dict) -> dict:
    return {
        "type": "object",
        "properties": props,
        "additionalProperties": False,
    }


# --------------------------------------------------------------------------- #
# Tool specifications (all qgis.* namespaces)
# --------------------------------------------------------------------------- #
def build_registry() -> ToolRegistry:
    r = ToolRegistry()

    def add(name, namespace, description, input_spec, output_spec,
            permissions=None, timeout=300, approval=False, verification=None):
        r.register(ToolSpec(
            name=name, namespace=namespace, description=description,
            input_schema=input_spec, output_schema=output_spec,
            permissions=permissions or [], timeout_seconds=timeout,
            require_approval=approval,
            verification_rules=verification or [],
        ))

    # ---- qgis.system ----
    add(
        "qgis.system.inspect", "qgis.system",
        "Inspect the QGIS installation: version, GDAL version, Python version, bridge status.",
        base_input(),
        base_output({"qgis_version": _str_prop("QGIS version"),
                     "gdal_version": _str_prop("GDAL version"),
                     "python_version": _str_prop("Python version"),
                     "bridge_connected": _bool_prop("Whether the bridge is connected")}),
        permissions=["qgis:read"],
    )
    add(
        "qgis.system.health", "qgis.system",
        "Check health of the QGIS Bridge and active QGIS instance.",
        base_input(),
        base_output({"qgis_connected": _bool_prop("value"),
                     "project_open": _bool_prop("value"),
                     "layer_count": _int_prop("Number of loaded layers"),
                     "main_thread": _bool_prop("main thread")}),
        permissions=["qgis:read"],
    )

    # ---- qgis.project ----
    add(
        "qgis.project.open", "qgis.project",
        "Open a QGIS project file (.qgz/.qgs).",
        base_input(required=["path"], properties={"path": _str_prop("Path to the project file")}),
        base_output({"project_file": _str_prop(),
                     "project_title": _str_prop(),
                     "crs": _str_prop(),
                     "layer_count": _int_prop()}),
        permissions=["qgis:project:write"],
        approval=True,
        verification=["file_exists", "project_valid"],
    )
    add(
        "qgis.project.save", "qgis.project",
        "Save the current QGIS project.",
        base_input(properties={"path": _str_prop("Optional path to save to")}),
        base_output({"saved": _bool_prop("value"), "project_file": _str_prop()}),
        permissions=["qgis:project:write"],
        approval=False,
        verification=["file_written"],
    )
    add(
        "qgis.project.inspect", "qgis.project",
        "Inspect the current QGIS project: metadata, CRS, layers.",
        base_input(),
        base_output({"project_file": _str_prop(),
                     "project_title": _str_prop(),
                     "crs": _str_prop(),
                     "layer_count": _int_prop(),
                     "layers": _list_prop("layers")}),
        permissions=["qgis:read"],
    )

    # ---- qgis.layers ----
    add(
        "qgis.layers.inspect", "qgis.layers",
        "Inspect all loaded layers: id, name, type, validity, CRS, extent, fields.",
        base_input(),
        base_output({"layers": _list_prop("layer list"),
                     "count": _int_prop()}),
        permissions=["qgis:read"],
    )
    add(
        "qgis.layers.load", "qgis.layers",
        "Load a GIS dataset (vector or raster) into the project.",
        base_input(required=["path"], properties={
            "path": _str_prop("File path to load"),
            "layer_name": _str_prop("Optional layer name"),
            "provider": _str_prop("Provider hint: vector|raster"),
        }),
        base_output({"id": _str_prop(), "name": _str_prop(),
                     "type": _str_prop(), "valid": _bool_prop("value"), "crs": _str_prop()}),
        permissions=["qgis:layer:write"],
        approval=False,
        verification=["file_exists", "layer_valid"],
    )
    add(
        "qgis.layers.remove", "qgis.layers",
        "Remove a layer from the project by layer id.",
        base_input(required=["layer_id"], properties={"layer_id": _str_prop("Layer id to remove")}),
        base_output({"removed": _bool_prop("value"), "id": _str_prop()}),
        permissions=["qgis:layer:write"],
        approval=True,
        verification=["layer_removed"],
    )

    # ---- qgis.canvas ----
    add(
        "qgis.canvas.inspect", "qgis.canvas",
        "Inspect the map canvas: extent, CRS, scale, rotation, visible layers.",
        base_input(),
        base_output({"extent": _list_prop("canvas extent", "number"),
                     "crs": _str_prop(), "scale": _num_prop(),
                     "rotation": _num_prop(), "layers": _list_prop("layer ids")}),
        permissions=["qgis:read"],
    )

    # ---- qgis.screen ----
    add(
        "qgis.screen.capture", "qgis.screen",
        "Capture a screenshot of the QGIS map canvas. Returns PNG as base64.",
        base_input(),
        base_output({"image_base64": _str_prop("PNG base64"),
                     "width": _int_prop(), "height": _int_prop(),
                     "format": _str_prop()}),
        permissions=["qgis:screen:read"],
    )

    # ---- qgis.cursor ----
    for tool, desc, pname in [
        ("qgis.cursor.move", "Move the AI cursor to a screen position.", [("x", _int_prop("Screen X")), ("y", _int_prop("Screen Y"))]),
        ("qgis.cursor.click", "Click at the current AI cursor position.", []),
        ("qgis.cursor.drag", "Drag from one screen position to another.", [("x1", _int_prop("Start X")), ("y1", _int_prop("Start Y")), ("x2", _int_prop("End X")), ("y2", _int_prop("End Y"))]),
    ]:
        props = {n: p for n, p in pname}
        add(tool, "qgis.cursor", desc,
            base_input(required=[n for n, _ in pname], properties=props),
            base_output({"ok": _bool_prop("main thread")}),
            permissions=["qgis:cursor:write"],
        )

    # ---- qgis.keyboard ----
    add(
        "qgis.keyboard.type", "qgis.keyboard",
        "Type text into the focused QGIS control.",
        base_input(required=["text"], properties={"text": _str_prop("Text to type")}),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:keyboard:write"],
    )
    add(
        "qgis.keyboard.hotkey", "qgis.keyboard",
        "Press a keyboard shortcut (comma-separated keys).",
        base_input(required=["keys"], properties={"keys": _str_prop("Keys, e.g. ctrl,s")}),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:keyboard:write"],
    )

    # ---- qgis.mouse ----
    add(
        "qgis.mouse.scroll", "qgis.mouse",
        "Scroll the mouse wheel at the current position.",
        base_input(properties={"delta": _int_prop("Scroll delta")}),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:mouse:write"],
    )

    # ---- qgis.window / qgis.dialog ----
    add(
        "qgis.window.inspect", "qgis.window",
        "Inspect the QGIS main window: title, size, state.",
        base_input(),
        base_output({"title": _str_prop(), "size": _list_prop("size", "number")}),
        permissions=["qgis:read"],
    )
    add(
        "qgis.dialog.inspect", "qgis.dialog",
        "Inspect open QGIS dialogs.",
        base_input(),
        base_output({"dialogs": _list_prop("open dialogs")}),
        permissions=["qgis:read"],
    )

    # ---- qgis.algorithms ----
    add(
        "qgis.algorithms.discover", "qgis.algorithms",
        "Discover installed QGIS Processing algorithms (dynamic, version-aware).",
        base_input(),
        base_output({"algorithms": _list_prop("algorithms"), "count": _int_prop()}),
        permissions=["qgis:read"],
    )
    add(
        "qgis.algorithms.execute", "qgis.algorithms",
        "Execute a QGIS Processing algorithm by id with parameters.",
        base_input(required=["algorithm"], properties={
            "algorithm": _str_prop("Algorithm id, e.g. native:buffer"),
            "parameters": {"type": "object", "description": "Algorithm parameters"},
        }),
        base_output({"outputs": {"type": "object"}, "algorithm": _str_prop()}),
        permissions=["qgis:algorithm:execute"],
        approval=False,
        verification=["output_exists", "output_valid"],
    )

    # ---- qgis.georeferencing / qgis.gcp ----
    add(
        "qgis.georeference.analyze", "qgis.georeference",
        "Analyze an image for georeferencing: dimensions, quality, landmarks, rotation.",
        base_input(required=["image_path"], properties={"image_path": _str_prop("Path to the scanned map image")}),
        base_output({"dimensions": _list_prop("dimensions", "number"),
                     "quality_score": _num_prop(),
                     "landmarks": _list_prop("landmarks"),
                     "rotation": _num_prop()}),
        permissions=["qgis:georeference:read"],
    )
    add(
        "qgis.gcp.generate", "qgis.gcp",
        "Generate candidate Ground Control Points from image + reference data.",
        base_input(required=["image_path"], properties={
            "image_path": _str_prop(),
            "reference_source": _str_prop("Reference raster or dataset"),
        }),
        base_output({"gcps": _list_prop("gcp candidates"),
                     "count": _int_prop()}),
        permissions=["qgis:gcp:write"],
        verification=["confidence_scored", "outliers_rejected"],
    )
    add(
        "qgis.gcp.validate", "qgis.gcp",
        "Validate candidate GCPs: duplicates, outliers, distribution, residuals.",
        base_input(required=["gcps"], properties={"gcps": _list_prop("gcps")}),
        base_output({"valid_gcps": _list_prop(), "rmse": _num_prop(),
                     "rejected": _list_prop()}),
        permissions=["qgis:gcp:write"],
        verification=["min_point_count", "residuals_checked"],
    )

    # ---- qgis.raster / qgis.vector / qgis.spatial ----
    add(
        "qgis.raster.*", "qgis.raster",
        "Raster processing operations (calculation, reclassify, mosaic, clip, resample).",
        base_input(),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:raster:write"],
    )
    add(
        "qgis.vector.*", "qgis.vector",
        "Vector processing operations (buffer, clip, dissolve, intersect, union).",
        base_input(),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:vector:write"],
    )
    add(
        "qgis.spatial.*", "qgis.spatial",
        "Spatial analysis operations (joins, proximity, overlay, interpolation).",
        base_input(),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:spatial:write"],
    )

    # ---- qgis.database / qgis.layout / qgis.workflow ----
    add(
        "qgis.database.*", "qgis.database",
        "Spatial database operations (GeoPackage, PostGIS, spatial SQL).",
        base_input(),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:database:write"],
    )
    add(
        "qgis.layout.*", "qgis.layout",
        "Map layout creation and export.",
        base_input(),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:layout:write"],
    )
    add(
        "qgis.workflow.execute", "qgis.workflow",
        "Execute a saved GIS workflow by id.",
        base_input(required=["workflow_id"], properties={"workflow_id": _str_prop()}),
        base_output({"ok": _bool_prop("value"), "job_id": _str_prop()}),
        permissions=["qgis:workflow:execute"],
    )

    # ---- qgis.agents / qgis.skills / qgis.verify / qgis.jobs / qgis.history ----
    add(
        "qgis.agents.*", "qgis.agents",
        "Agent management and delegation.",
        base_input(),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:agents:write"],
    )
    add(
        "qgis.skills.*", "qgis.skills",
        "Skill management (import, validate, assign).",
        base_input(),
        base_output({"ok": _bool_prop("main thread")}),
        permissions=["qgis:skills:write"],
    )
    add(
        "qgis.verify.*", "qgis.verify",
        "Verification engine: check operation results.",
        base_input(),
        base_output({"verification_state": _str_prop()}),
        permissions=["qgis:verify:read"],
    )
    add(
        "qgis.jobs.cancel", "qgis.jobs",
        "Cancel a running job by id.",
        base_input(required=["job_id"], properties={"job_id": _str_prop()}),
        base_output({"cancelled": _bool_prop("value"), "job_id": _str_prop()}),
        permissions=["qgis:jobs:write"],
    )
    add(
        "qgis.history.inspect", "qgis.history",
        "Inspect job/task history and events.",
        base_input(properties={"limit": _int_prop("Max records")}),
        base_output({"jobs": _list_prop("jobs")}),
        permissions=["qgis:history:read"],
    )

    # ---- qgis.plugins ----
    add(
        "qgis.plugins.*", "qgis.plugins",
        "Inspect installed QGIS plugins.",
        base_input(),
        base_output({"plugins": _list_prop("plugins")}),
        permissions=["qgis:read"],
    )

    return r
