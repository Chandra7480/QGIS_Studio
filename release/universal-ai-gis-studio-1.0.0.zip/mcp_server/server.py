"""Universal AI GIS Studio — Universal MCP Server (low-level MCP Server).

Uses mcp.server.lowlevel.Server so every tool has a strict inputSchema
(declared in ToolRegistry). Exposes stdio and Streamable HTTP transports.
All tools call the QGIS Bridge and return verified, structured results.
"""

import json
import uuid
import anyio
from typing import Optional, List

from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from mcp_server.registry import build_registry, ToolSpec
from mcp_server.qgis_client import QgisBridgeClient
from core.logging import get_logger
from core.exceptions import MCPError, BridgeError

logger = get_logger("mcp.server")


class UniversalMCPServer:
    def __init__(self, bridge_url: str = "http://127.0.0.1:8765",
                 auth_token: Optional[str] = None,
                 name: str = "universal-ai-gis-studio"):
        self.bridge_url = bridge_url
        self.auth_token = auth_token
        self.name = name
        self.client = QgisBridgeClient(base_url=bridge_url, auth_token=auth_token)
        self.registry = build_registry()

        self.server = Server(name)
        self._setup_handlers()

    # ------------------------------------------------------------------ #
    # Handler setup
    # ------------------------------------------------------------------ #
    def _setup_handlers(self):
        server = self.server
        registry = self.registry

        @server.list_tools()
        async def list_tools() -> List[Tool]:
            tools = []
            for spec in registry.all():
                tools.append(Tool(
                    name=spec.name,
                    description=spec.description,
                    inputSchema=spec.input_schema,
                ))
            logger.info("Listed %d MCP tools", len(tools))
            return tools

        @server.call_tool()
        async def call_tool(name: str, arguments: dict) -> List[TextContent]:
            spec = registry.get(name)
            if spec is None:
                raise MCPError(f"Unknown tool: {name}")
            return self._execute_tool(spec, arguments or {})

    # ------------------------------------------------------------------ #
    # Tool execution
    # ------------------------------------------------------------------ #
    def _execute_tool(self, spec: ToolSpec, params: dict) -> List[TextContent]:
        request_id = f"req_{uuid.uuid4().hex[:12]}"
        try:
            result = self.client.dispatch(
                tool=spec.name, params=params, request_id=request_id,
                timeout_seconds=spec.timeout_seconds,
            )
            status = result.get("status", "error")
            verification = result.get("verification_state", "UNKNOWN")
            if status == "error":
                err = result.get("error", {})
                raise MCPError(
                    f"Tool {spec.name} failed: {err.get('message', 'unknown error')}",
                    context={"code": err.get("code"), "request_id": request_id,
                             "verification_state": verification},
                )
            out = {
                "request_id": request_id,
                "tool": spec.name,
                "status": status,
                "verification_state": verification,
                "result": result.get("result", {}),
                "job_id": result.get("job_id"),
                "timestamp": result.get("timestamp"),
            }
            return [TextContent(type="text", text=json.dumps(out, indent=2))]
        except MCPError:
            raise
        except BridgeError:
            raise
        except Exception as exc:
            logger.exception("MCP tool %s failed", spec.name)
            raise MCPError(f"Tool {spec.name} error: {exc}") from exc

    # ------------------------------------------------------------------ #
    # Transports
    # ------------------------------------------------------------------ #
    def run_stdio(self):
        """Run on stdio transport (OpenCode / local MCP clients)."""

        async def _run():
            async with stdio_server() as (read_stream, write_stream):
                await self.server.run(
                    read_stream, write_stream,
                    self.server.create_initialization_options(),
                )

        anyio.run(_run)

    def streamable_http_app(self):
        """Return an ASGI app serving Streamable HTTP transport."""
        from mcp.server.streamable_http_manager import (
            StreamableHTTPSessionManager, ASGIApp,
        )
        manager = StreamableHTTPSessionManager(
            app=self.server,
            stateless=False,
            json_response=False,
        )
        return ASGIApp(manager)

    def run_streamable_http(self, host: str = "127.0.0.1", port: int = 8766):
        """Run Streamable HTTP via uvicorn if available."""
        try:
            import uvicorn  # type: ignore
        except ImportError as exc:
            raise BridgeError(
                "uvicorn is required for Streamable HTTP transport. "
                "Install it or use stdio transport."
            ) from exc
        app = self.streamable_http_app()
        uvicorn.run(app, host=host, port=port, log_level="info")
