"""Repository for audit_logs."""

from ..db import Database


class AuditRepository:
    def __init__(self, db: Database):
        self.db = db

    def log(self, actor: str, action: str, target: str | None, outcome: str, details: dict | None = None, ip: str | None = None) -> None:
        import json
        self.db.execute(
            """
            INSERT INTO audit_logs(actor, action, target, outcome, details, ip)
            VALUES(?, ?, ?, ?, ?, ?)
            """,
            (actor, action, target, outcome,
             json.dumps(details) if details else None, ip),
        )

    def list(self, limit: int = 100) -> list:
        import json
        rows = self.db.fetchall(
            "SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?", (limit,)
        )
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["details"] = json.loads(d["details"]) if d["details"] else None
            except Exception:
                pass
            result.append(d)
        return result
