"""Universal AI GIS Studio — SQLite database connection manager.

Provides a thread-safe SQLite connection with WAL mode, foreign keys,
migrations, and transaction support. All access goes through this
manager or repository classes — never direct SQL in UI components.
"""

import os
import sqlite3
import threading
from contextlib import contextmanager
from typing import Any, Dict, Optional

from core.logging import get_logger
from core.exceptions import DatabaseError

logger = get_logger("database")


class Database:
    """SQLite database manager.

    Uses check_same_thread=False with a lock to allow use across
    worker threads while serializing writes via the connection lock.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._initialized = False

    def connect(self) -> sqlite3.Connection:
        """Open (or reuse) the database connection."""
        if self._conn is not None:
            return self._conn
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        try:
            self._conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
                timeout=30,
                isolation_level=None,  # autocommit; we manage transactions explicitly
            )
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.execute("PRAGMA temp_store=MEMORY")
            logger.info("Database connected: %s", self.db_path)
        except sqlite3.Error as exc:
            raise DatabaseError(f"Failed to open database {self.db_path}: {exc}") from exc
        return self._conn

    @contextmanager
    def transaction(self):
        """Context manager for a transactional block.

        Uses explicit BEGIN/COMMIT in autocommit mode (isolation_level=None)
        so callers can group multiple statements into one atomic unit.
        """
        conn = self.connect()
        with self._lock:
            conn.execute("BEGIN")
            try:
                yield conn
                conn.execute("COMMIT")
            except Exception:
                try:
                    conn.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                raise

    def execute_script(self, sql: str) -> None:
        """Execute a multi-statement SQL script (DDL) outside a transaction.

        Safe to call in autocommit mode; each statement commits independently.
        """
        conn = self.connect()
        with self._lock:
            try:
                conn.executescript(sql)
            except sqlite3.Error as exc:
                raise DatabaseError(f"SQL script execution failed: {exc}") from exc

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        conn = self.connect()
        with self._lock:
            try:
                return conn.execute(sql, params)
            except sqlite3.Error as exc:
                raise DatabaseError(f"SQL execution failed: {exc}\nSQL: {sql}") from exc

    def executemany(self, sql: str, params: list) -> sqlite3.Cursor:
        conn = self.connect()
        with self._lock:
            try:
                return conn.executemany(sql, params)
            except sqlite3.Error as exc:
                raise DatabaseError(f"SQL executemany failed: {exc}\nSQL: {sql}") from exc

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[sqlite3.Row]:
        cur = self.execute(sql, params)
        return cur.fetchone()

    def fetchall(self, sql: str, params: tuple = ()) -> list:
        cur = self.execute(sql, params)
        return cur.fetchall()

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                except sqlite3.Error:
                    pass
                self._conn = None
                logger.info("Database closed: %s", self.db_path)

    def get_all_settings(self) -> Dict[str, str]:
        """Return all app_settings as a dict (used by Config loader)."""
        rows = self.fetchall("SELECT key, value FROM app_settings")
        return {row["key"]: row["value"] for row in rows}

    def set_setting(self, key: str, value: str) -> None:
        with self.transaction() as conn:
            conn.execute(
                "INSERT INTO app_settings(key, value, updated_at) VALUES(?, ?, datetime('now')) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')",
                (key, value),
            )

    def is_initialized(self) -> bool:
        return self._initialized

    def mark_initialized(self) -> None:
        self._initialized = True
