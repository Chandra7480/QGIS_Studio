"""Universal AI GIS Studio — Base Agent."""

import logging
from typing import Optional

logger = logging.getLogger("uagis.agents")


class BaseAgent:
    def __init__(self, agent_id: str, name: str, description: str,
                 instructions: str, permission_level: str = "standard",
                 max_steps: int = 10, timeout_seconds: int = 300,
                 ai_host_id: str | None = None):
        self.agent_id = agent_id
        self.name = name
        self.description = description
        self.instructions = instructions
        self.permission_level = permission_level
        self.max_steps = max_steps
        self.timeout_seconds = timeout_seconds
        self.ai_host_id = ai_host_id
        self.enabled = True

    def can_use_tool(self, tool_permission: str) -> bool:
        """Simple permission check."""
        levels = {"read": 1, "standard": 2, "elevated": 3}
        need = {"read": 1, "standard": 2, "elevated": 3}.get(tool_permission, 2)
        have = levels.get(self.permission_level, 2)
        return have >= need

    def execute_task(self, task: dict) -> dict:
        """Execute a delegated task. Subclasses implement real logic."""
        return {
            "agent_id": self.agent_id,
            "task": task,
            "status": "delegated",
            "note": f"{self.name} accepted task (implement tool dispatch via orchestrator)",
        }

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id, "name": self.name,
            "description": self.description, "permission_level": self.permission_level,
            "max_steps": self.max_steps, "timeout_seconds": self.timeout_seconds,
            "enabled": self.enabled,
        }
