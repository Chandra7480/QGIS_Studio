"""Custom agent builder."""
