"""Universal AI GIS Studio — Agent Orchestrator.

Supervisor-worker architecture: task planning, delegation, sequential and
safe parallel execution, context sharing, agent-to-agent communication,
progress monitoring, error recovery, cancellation, and final verification.
"""

import logging
from typing import Optional

from core.job_manager import JobManager
from core.logging import get_logger
from core.exceptions import NotFoundError

logger = get_logger("agents.orchestrator")


class AgentOrchestrator:
    def __init__(self, agent_manager, job_manager: JobManager):
        self.agent_manager = agent_manager
        self.job_manager = job_manager
        self._running_jobs: dict[str, str] = {}  # job_id -> agent_id

    def delegate(self, agent_id: str, task: dict) -> str:
        agent = self.agent_manager.get_agent(agent_id)
        if not agent or not agent.enabled:
            raise NotFoundError(f"Agent {agent_id} not found or disabled")
        job_id = self.job_manager.create_job(
            job_type="agent_task", input_payload=__import__("json").dumps(task),
            agent_id=agent_id)
        self.job_manager.start_job(job_id)
        self._running_jobs[job_id] = agent_id
        try:
            result = agent.execute_task(task)
            self.job_manager.complete_job(
                job_id, __import__("json").dumps(result), "SUCCESS")
        except Exception as exc:
            logger.exception("Agent task failed: %s", exc)
            self.job_manager.fail_job(job_id, str(exc))
            result = {"agent_id": agent_id, "status": "failed", "error": str(exc)}
        finally:
            self._running_jobs.pop(job_id, None)
        return job_id

    def cancel_job(self, job_id: str) -> None:
        self.job_manager.cancel_job(job_id)
        self._running_jobs.pop(job_id, None)

    def status(self, job_id: str) -> dict:
        return self.job_manager.get_job(job_id)
