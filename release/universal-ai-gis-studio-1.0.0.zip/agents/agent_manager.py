"""Universal AI GIS Studio — Agent Manager.

Manages built-in and custom agents, tool/skill assignments, permissions.
"""

import logging
import uuid
from typing import Optional

from database.db import Database
from core.exceptions import NotFoundError
from agents.base_agent import BaseAgent
from agents.custom.custom_builder import CustomAgentBuilder

logger = logging.getLogger("uagis.agent_manager")


class AgentManager:
    def __init__(self, db: Database):
        self.db = db
        self._agents: dict[str, BaseAgent] = {}
        self._builtin_defs = self._builtin_definitions()
        self._custom_builder = CustomAgentBuilder(db)

    # ------------------------------------------------------------------ #
    # Built-in agents
    # ------------------------------------------------------------------ #
    def _builtin_definitions(self) -> dict[str, dict]:
        return {
            "agent_gis_supervisor": {
                "name": "GIS Supervisor Agent",
                "description": "Plans and delegates GIS tasks to specialist workers.",
                "permission_level": "elevated",
            },
            "agent_gis_research": {
                "name": "GIS Research Agent",
                "description": "Researches GIS data and methods.",
                "permission_level": "read",
            },
            "agent_data_acquisition": {
                "name": "Data Acquisition Agent",
                "description": "Discovers and imports datasets.",
                "permission_level": "standard",
            },
            "agent_data_management": {
                "name": "Data Management Agent",
                "description": "Organizes layers and metadata.",
                "permission_level": "standard",
            },
            "agent_georeferencing": {
                "name": "Georeferencing Agent",
                "description": "Automatic georeferencing of scanned maps.",
                "permission_level": "standard",
            },
            "agent_digitization": {
                "name": "Digitization Agent",
                "description": "Digitizes features from imagery/maps.",
                "permission_level": "standard",
            },
            "agent_vector_processing": {
                "name": "Vector Processing Agent",
                "description": "Buffer, clip, dissolve, overlay operations.",
                "permission_level": "standard",
            },
            "agent_raster_processing": {
                "name": "Raster Processing Agent",
                "description": "Raster calculation, reclassify, mosaic.",
                "permission_level": "standard",
            },
            "agent_spatial_analysis": {
                "name": "Spatial Analysis Agent",
                "description": "Joins, proximity, overlay, interpolation.",
                "permission_level": "standard",
            },
            "agent_terrain": {
                "name": "Terrain Analysis Agent",
                "description": "Slope, aspect, hillshade, contours.",
                "permission_level": "standard",
            },
            "agent_hydrology": {
                "name": "Hydrology Agent",
                "description": "Flow, watershed, stream extraction.",
                "permission_level": "standard",
            },
            "agent_network": {
                "name": "Network Analysis Agent",
                "description": "Shortest path, service areas, routing.",
                "permission_level": "standard",
            },
            "agent_remote_sensing": {
                "name": "Remote Sensing Agent",
                "description": "Satellite imagery, band combinations, indices.",
                "permission_level": "standard",
            },
            "agent_classification": {
                "name": "Image Classification Agent",
                "description": "Supervised/unsupervised classification.",
                "permission_level": "standard",
            },
            "agent_change_detection": {
                "name": "Change Detection Agent",
                "description": "Temporal comparison, land-cover change.",
                "permission_level": "standard",
            },
            "agent_3d_gis": {
                "name": "3D GIS Agent",
                "description": "3D visualization and terrain models.",
                "permission_level": "standard",
            },
            "agent_lidar": {
                "name": "LiDAR Agent",
                "description": "Point-cloud inspection and terrain extraction.",
                "permission_level": "standard",
            },
            "agent_survey_gps": {
                "name": "Survey and GPS Agent",
                "description": "GPS import and coordinate validation.",
                "permission_level": "standard",
            },
            "agent_cadastral": {
                "name": "Cadastral Agent",
                "description": "Parcel management and boundary digitization.",
                "permission_level": "standard",
            },
            "agent_cartography": {
                "name": "Cartography Agent",
                "description": "Symbology, labels, layouts, export.",
                "permission_level": "standard",
            },
            "agent_temporal_gis": {
                "name": "Temporal GIS Agent",
                "description": "Time-enabled layers and temporal analysis.",
                "permission_level": "standard",
            },
            "agent_database": {
                "name": "Database Agent",
                "description": "GeoPackage, PostGIS, spatial SQL.",
                "permission_level": "standard",
            },
            "agent_web_gis": {
                "name": "Web GIS Agent",
                "description": "WMS, WFS, WMTS, XYZ tiles.",
                "permission_level": "standard",
            },
            "agent_automation": {
                "name": "Automation Agent",
                "description": "Processing models and batch workflows.",
                "permission_level": "standard",
            },
            "agent_quality_control": {
                "name": "Quality Control Agent",
                "description": "Geometry, topology, CRS, attribute validation.",
                "permission_level": "standard",
            },
            "agent_reporting": {
                "name": "Reporting Agent",
                "description": "Generates GIS reports and map exports.",
                "permission_level": "read",
            },
            "agent_visual_desktop_control": {
                "name": "Visual Desktop Control Agent",
                "description": "Controls QGIS GUI via screen/cursor/mouse/keyboard.",
                "permission_level": "elevated",
            },
            "agent_computer_vision": {
                "name": "Computer Vision Agent",
                "description": "Landmark detection and image registration.",
                "permission_level": "standard",
            },
            "agent_gis_verification": {
                "name": "GIS Verification Agent",
                "description": "Verifies operation results and GCP residuals.",
                "permission_level": "read",
            },
        }

    def list_agents(self) -> list[dict]:
        out = []
        for aid, d in self._builtin_defs.items():
            out.append({"agent_id": aid, **d, "agent_type": "builtin"})
        for aid, agent in self._agents.items():
            if aid not in self._builtin_defs:
                out.append(agent.to_dict() | {"agent_type": "custom"})
        return out

    def get_agent(self, agent_id: str) -> Optional[BaseAgent]:
        if agent_id in self._agents:
            return self._agents[agent_id]
        if agent_id in self._builtin_defs:
            d = self._builtin_defs[agent_id]
            agent = BaseAgent(
                agent_id=agent_id, name=d["name"], description=d["description"],
                instructions=f"Instructions for {d['name']}",
                permission_level=d["permission_level"],
            )
            self._agents[agent_id] = agent
            return agent
        return None

    # ------------------------------------------------------------------ #
    # Custom agents
    # ------------------------------------------------------------------ #
    def create_custom_agent(self, spec: dict) -> str:
        return self._custom_builder.create(spec)

    def get_custom_agent(self, agent_id: str) -> Optional[dict]:
        return self._custom_builder.get(agent_id)
